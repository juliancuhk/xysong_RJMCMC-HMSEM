#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>

#include "nrutil.c"
#include "def_con.h"

#include "array.c"
#include "ran2.c"
#include "expdev.c"
#include "gasdev.c"
#include "gamdev.c"
#include "ludcmp.c"
#include "lubksb.c"
#include "iv.c"
#include "choldc.c"
#include "cholsl.c"

#include "readtransmatrix.c"
#include "generatehiddenstate.c"
#include "readtrueparameters.c"
#include "gene.c"
#include "read1.c"
#include "read3.c"
#include "read4.c"
#include "csig.c"
#include "detem.c"
#include "updatezc.c"
#include "updatezid.c"
#include "fac1.c"
#include "rela.c"
#include "newph.c"
#include "newmu.c"
#include "newsy.c"
#include "news1.c"
#include "orderparameters.c"
#include "rel1.c"

#include "jumpto.c"
#include "choosesplitnum.c"
#include "choosemergenum.c"
#include "randombeta.c"
#include "stationaryvector.c"
#include "splitprobabilitymatrix.c"
#include "splitsemparameters.c"
#include "mergeprobabilitymatrix.c"
#include "diagnose.c"
#include "splitzid.c"
#include "jumprate.c"
#include "gammln.c"
#include "calculatetransprratio.c"
#include "determinant.c"
#include "calculatematrix.c"
#include "normaldistributionpdf.c"
#include "betadistributionpdf.c"
#include "acceptsplitprobability.c"
#include "changeparameters.c"
#include "pbpitobi.c"
#include "mergesemparameters.c"
#include "mergezid.c"
#include "acceptmergeprobability.c"

main()
{int i,j,k,CIR,GIB,m,n,currenthiddenstate,zc,g,num,wt,ii,jj;
 double TOPP,u1,u2,u3,u4;
 long random1,random2,random3;

 FILE *dat1;
 int **ZID,**ZD;
 double **TRANSPR,***LY,**MU,**PSX,***BI,***PB,***PHI,***PI,**PSD,***YO, ***TUE;
 int *ROY,**CLY,*ROB,**CLB,**IDY,**IDB;
 double *hypermu,**PPSG,**ma,***SIGMA,***XSIG,*MSU,***XI,***NXI,***YYO,***NX1,***NX2,*NEYO;
 
 TRANSPR=matrix(1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 ZID=imatrix(1,NO,1,NT);
 ZD=imatrix(1,NO,1,NT);
 LY=f3tensor(1,MAXHIDDENSTATE,1,NY,1,NK);
 MU=matrix(1,MAXHIDDENSTATE,1,NY);
 PSX=matrix(1,MAXHIDDENSTATE,1,NY);
 BI=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NK);
 PB=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NZ);
 PHI=f3tensor(1,MAXHIDDENSTATE,1,NZ,1,NZ);
 PI=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NM);
 PSD=matrix(1,MAXHIDDENSTATE,1,NM);
 YO=f3tensor(1,NO,1,NT,1,NY);
 TUE=f3tensor(1,NO,1,NT,1,NK);
 ROY=ivector(1,NY);
 CLY=imatrix(1,NY,1,NK);
 ROB=ivector(1,NM);
 CLB=imatrix(1,NM,1,NK);
 IDY=imatrix(1,NY,1,NK);
 IDB=imatrix(1,NM,1,NK);
 hypermu=vector(1,NY);
 PPSG=matrix(1,NY,1,NY);
 ma=matrix(1,NY,1,NY);
 SIGMA=f3tensor(1,MAXHIDDENSTATE,1,NY,1,NY);
 XSIG=f3tensor(1,MAXHIDDENSTATE,1,NK,1,NK);
 MSU=vector(1,NK);
 XI=f3tensor(1,NO,1,NT,1,NK);
 NXI=f3tensor(1,MAXHIDDENSTATE,1,NO*NT,1,NK);
 YYO=f3tensor(1,MAXHIDDENSTATE,1,NO*NT,1,NY);
 NX1=f3tensor(1,MAXHIDDENSTATE,1,NO*NT,1,NM);
 NX2=f3tensor(1,MAXHIDDENSTATE,1,NO*NT,1,NZ);
 NEYO=vector(1,NO*NT);
 
 double **PMU,***PLY,***PBI;      /*some hyperparameters*/
 double **mucov,*MID,*PROP;
 mucov=matrix(1,NY,1,NY);
 PMU=matrix(1,MAXHIDDENSTATE,1,NY);
 PLY=f3tensor(1,MAXHIDDENSTATE,1,NY,1,NK);
 PBI=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NK);
 MID=vector(1,NY);
 PROP=vector(1,MAXHIDDENSTATE);
 
 int **TRANSNUM,*COMPONENTNUM;
 TRANSNUM=imatrix(1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 COMPONENTNUM=ivector(1,MAXHIDDENSTATE);
 
 double **ETRANSPR,***ELY,**EMU,**EPSX,***EBI,***EPHI,**EPSD;
 ETRANSPR=matrix(1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 ELY=f3tensor(1,MAXHIDDENSTATE,1,NY,1,NK);
 EMU=matrix(1,MAXHIDDENSTATE,1,NY);
 EPSX=matrix(1,MAXHIDDENSTATE,1,NY);
 EBI=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NK);
 EPHI=f3tensor(1,MAXHIDDENSTATE,1,NZ,1,NZ);
 EPSD=matrix(1,MAXHIDDENSTATE,1,NM);
 
 int proposalhiddenstate,mergenum,splitnum,**SAUXZID;
 double *generaterandom,*proposalrandomvalue,**SAUXTRANS,**MAUXTRANS,*mergerandom,*mergerandomnum,***SAUXLY,**SAUXMU,**SAUXPSX,***SAUXPB,***SAUXPHI,***SAUXPI,**SAUXPSD,*shapeparameter;
 generaterandom=vector(1,100);
 proposalrandomvalue=vector(1,100);
 SAUXTRANS=matrix(1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 MAUXTRANS=matrix(1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 mergerandom=vector(1,100);
 mergerandomnum=vector(1,100);
 SAUXLY=f3tensor(1,MAXHIDDENSTATE,1,NY,1,NK);
 SAUXMU=matrix(1,MAXHIDDENSTATE,1,NY);
 SAUXPSX=matrix(1,MAXHIDDENSTATE,1,NY);
 SAUXPB=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NZ);
 SAUXPHI=f3tensor(1,MAXHIDDENSTATE,1,NZ,1,NZ);
 SAUXPI=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NM);
 SAUXPSD=matrix(1,MAXHIDDENSTATE,1,NM);
 SAUXZID=imatrix(1,NO,1,NT);
 shapeparameter=vector(1,2);
 
 double ***MAUXLY,**MAUXMU,**MAUXPSX,***MAUXPB,***MAUXPHI,***MAUXPI,**MAUXPSD,*randomvalued;
 int **MAUXZID;
 MAUXLY=f3tensor(1,MAXHIDDENSTATE,1,NY,1,NK);
 MAUXMU=matrix(1,MAXHIDDENSTATE,1,NY);
 MAUXPSX=matrix(1,MAXHIDDENSTATE,1,NY);
 MAUXPB=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NZ);
 MAUXPHI=f3tensor(1,MAXHIDDENSTATE,1,NZ,1,NZ);
 MAUXPI=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NM);
 MAUXPSD=matrix(1,MAXHIDDENSTATE,1,NM);
 MAUXZID=imatrix(1,NO,1,NT);
 randomvalued=vector(1,100);
 
 int *componentnum,*countnum;
 double *countp;
 componentnum=ivector(1,MCAX);
 countnum=ivector(1,MAXHIDDENSTATE);
 countp=vector(1,MAXHIDDENSTATE);
 
 char name[50];
 FILE *dat2,*dat3;
 
 srand(2);
 
 for(CIR=1;CIR<=REPEATNUM;CIR++)
 {
  read1(CLB, CLY, IDB, IDY, ROB, ROY);    
  readtransmatrix(TRANSPR);                               /*read true transition matrix*/           
  generatehiddenstate(ZID,TRANSPR);                      /*generate true state*/
  readtrueparameters(LY,MU,PSX,PB,PHI,PI,PSD);         /*read true parameters in SEM*/
  gene(LY,MU,PSX,PB,PHI,PI,PSD,YO,TUE,ZID);          /*generate observed data*/
  
   
  for(i=1;i<=NY;i++)
    hypermu[i]=0.0;    
         
   for(i=1;i<=NY;i++)
    for(j=1;j<=NY;j++)
     {if(i==j) ma[i][j]=1.0;
       else ma[i][j]=0.0;}   
    
  for(i=1;i<=NY;i++)
    for(j=1;j<=NY;j++)
     mucov[i][j]=ma[i][j];
      
  iv(ma,NY+1);
    
  for(i=1;i<=NY;i++)
    for(j=1;j<=NY;j++)
     PPSG[i][j]=ma[i][j];    
     
     for(i=1;i<=MAXHIDDENSTATE;i++)
      for(j=1;j<=NY;j++)
       PMU[i][j]=hypermu[j];   /*the hyperparameter of MU*/
       
     read3(TRANSPR,LY,PLY,MU,PSX);  /*read the initial value of the parameters in measurement equation*/   /*also specify the hyperparameter in the prior of LY*/  
     
     read4(BI,PB,PBI,PHI,PI,PSD);   /*read the initial value of the parameters in structural equation*/   /*also specify the hyperparameter in the prior of BI*/ 
  
   for(i=1;i<=NO;i++)
    for(j=1;j<=NT;j++)
     ZID[i][j]=1;            /*initial hiddenstate value*/
      
     
    currenthiddenstate=2;    
    for(GIB=1;GIB<=MCAX;GIB++)
    {
     for(i=1;i<=currenthiddenstate;i++)  COMPONENTNUM[i]=0;
     
     for(i=1;i<=currenthiddenstate;i++)
      for(j=1;j<=currenthiddenstate;j++)
       TRANSNUM[i][j]=0;
       
     csig(currenthiddenstate,LY, PB, PHI, PI, PSD, PSX, SIGMA, XSIG);
          
     for(i=1;i<=NO;i++)
      for(j=1;j<=NT;j++)
       { 
        for(k=1;k<=NY;k++)
          MID[k]=YO[i][j][k];
          
          ii=i;
          jj=j;
          
          //zc=updatezc(currenthiddenstate,MID,MU,TRANSPR,SIGMA);
          
          zc=updatezid(ii,jj,ZID,currenthiddenstate,MID,MU,TRANSPR,SIGMA);            /*update hidden state*/
          
          ZD[i][j]=zc;
          
          COMPONENTNUM[zc]+=1;
                    
          if(j>1) TRANSNUM[ZD[i][j-1]][ZD[i][j]]+=1;
          
          for(k=1;k<=NY;k++)
           MID[k]=YO[i][j][k]-MU[zc][k];
           
           fac1(zc,MSU,XSIG);     /* MSU~N(0,XSIG)*/ 
      
             
      for(g=1;g<=NK;g++){
       for(k=1;k<=NK;k++)
        for(m=1;m<=NY;m++)
         MSU[g]+=XSIG[zc][g][k]*LY[zc][m][k]*MID[m]/PSX[zc][m];}   
         
         n=COMPONENTNUM[zc];
         
      for(k=1;k<=NK;k++)
      {XI[i][j][k]=MSU[k];
       NXI[zc][n][k]=XI[i][j][k];}
       
      for(k=1;k<=NY;k++)
       YYO[zc][n][k]=YO[i][j][k];
       /* partitioned y and xi according to the allocation variable */    
          
          } /*i,j*/
        
             
       for(i=1;i<=NO;i++)
        for(j=1;j<=NT;j++)
         ZID[i][j]=ZD[i][j];
          
       rela(currenthiddenstate,COMPONENTNUM, NXI, NX1, NX2);
	    /* partitioned NXI into NX1 (eta) and NX2 (xi) */   
         
       for(i=1;i<=currenthiddenstate;i++)
        {TOPP=0.0;
          for(j=1;j<=currenthiddenstate;j++) PROP[j]=0.0;
           
           for(j=1;j<=currenthiddenstate;j++)
           {random1=rand();
            num=TRANSNUM[i][j]+1;
            PROP[j]=gamdev(num,&random1);
            TOPP+=PROP[j];}
            
            for(j=1;j<=currenthiddenstate;j++)
             TRANSPR[i][j]=PROP[j]/TOPP;        /*update transfer probability matrix*/
           }    
           
          for(zc=1;zc<=currenthiddenstate;zc++)
           {newph(zc,COMPONENTNUM,PHI,NX2);              /*update PHI*/
            newmu(zc,NXI,LY,MU,COMPONENTNUM,PMU,PPSG,PSX,YYO);         /*update MU*/
           
           for(k=1; k<=NY; k++){
	          for(i=1;i<=COMPONENTNUM[zc];i++){
	             NEYO[i]=YYO[zc][i][k]-MU[zc][k];
	             for(j=1;j<=NK;j++)
		            NEYO[i]-=LY[zc][k][j]*NXI[zc][i][j]*(1.0-IDY[k][j]*1.0);
	          }
	          newsy(k,zc,CLY,COMPONENTNUM,NXI,LY,NEYO,PLY,PSX,ROY);}    /*update LY and PSX*/
	          
          for(k=1; k<=NM; k++){
	          for(i=1;i<=COMPONENTNUM[zc];i++){
	             NEYO[i]=NX1[zc][i][k];
	             for(j=1;j<=NK;j++)
		            NEYO[i]-=BI[zc][k][j]*NXI[zc][i][j]*(1.0-IDB[k][j]*1.0);}
	          
              news1(k,zc,CLB,COMPONENTNUM,NXI,BI,NEYO,PBI,PSD,ROB);}     /*update PSD*/
              
              }
     
           orderparameters(currenthiddenstate,MU,LY,PSX,BI,PHI,PSD,TRANSPR);      /*reorder the parameters*/  
            rel1(currenthiddenstate,BI, PB, PI);
           

     proposalhiddenstate=jumpto(currenthiddenstate);  
     if(proposalhiddenstate>currenthiddenstate)
     {splitnum=choosesplitnum(currenthiddenstate);
      splitprobabilitymatrix(currenthiddenstate,proposalhiddenstate,splitnum,TRANSPR,SAUXTRANS,generaterandom,shapeparameter);
      splitsemparameters(currenthiddenstate,proposalhiddenstate,splitnum,MU,SAUXMU,LY,SAUXLY,PSX,SAUXPSX,PB,SAUXPB,PI,SAUXPI,PSD,SAUXPSD,PHI,SAUXPHI,proposalrandomvalue);
      splitzid(currenthiddenstate,proposalhiddenstate,splitnum,ZID,SAUXZID,YO,SAUXMU,SAUXLY,SAUXPSX,XI);
      wt=diagnose(proposalhiddenstate,SAUXMU,SAUXTRANS);
      u2=acceptsplitprobability(currenthiddenstate,proposalhiddenstate,splitnum,ZID,SAUXZID,YO,TRANSPR,SAUXTRANS,MU,SAUXMU,LY,SAUXLY,PSX,SAUXPSX,PB,SAUXPB,PI,SAUXPI,PSD,SAUXPSD,PHI,SAUXPHI,XI,generaterandom,proposalrandomvalue,hypermu,mucov,shapeparameter);
      random2=rand();
      u1=ran2(&random2);
      if(wt&&u1<u2)
      {currenthiddenstate=proposalhiddenstate;
       changeparameters(currenthiddenstate,TRANSPR,SAUXTRANS,MU,SAUXMU,LY,SAUXLY,PHI,SAUXPHI,PSD,SAUXPSD,PSX,SAUXPSX,PB,SAUXPB,PI,SAUXPI);
       pbpitobi(currenthiddenstate,PB,PI,BI);
       }
      }
     else 
     {mergenum=choosemergenum(currenthiddenstate);
      mergeprobabilitymatrix(currenthiddenstate,proposalhiddenstate,mergenum,TRANSPR,MAUXTRANS,mergerandom);
      mergesemparameters(currenthiddenstate,proposalhiddenstate,mergenum,MU,MAUXMU,LY,MAUXLY,PSX,MAUXPSX,PB,MAUXPB,PI,MAUXPI,PSD,MAUXPSD,PHI,MAUXPHI,randomvalued);
      mergezid(currenthiddenstate,proposalhiddenstate,mergenum,ZID,MAUXZID);
      u3=acceptmergeprobability(currenthiddenstate,proposalhiddenstate,mergenum,ZID,MAUXZID,YO,TRANSPR,MAUXTRANS,MU,MAUXMU,LY,MAUXLY,PSX,MAUXPSX,PB,MAUXPB,PI,MAUXPI,PSD,MAUXPSD,PHI,MAUXPHI,mergerandom,randomvalued,XI,hypermu,mucov,shapeparameter);
      random3=rand();
      u4=ran2(&random3);
      if(u4<u3)
      {currenthiddenstate=proposalhiddenstate;
       changeparameters(currenthiddenstate,TRANSPR,MAUXTRANS,MU,MAUXMU,LY,MAUXLY,PHI,MAUXPHI,PSD,MAUXPSD,PSX,MAUXPSX,PB,MAUXPB,PI,MAUXPI);
       pbpitobi(currenthiddenstate,PB,PI,BI);
       }
      }
       
    
     printf("%d\n",GIB);
     
    componentnum[GIB]=currenthiddenstate;
    
    sprintf(name,"%s%d%s","record",CIR,".txt");
    dat2=fopen(name,"a");
    fprintf(dat2,"%d    ",currenthiddenstate);
    fclose(dat2);
     
     } /*GIB*/
  
 
  for(i=1;i<=MAXHIDDENSTATE;i++)
   countnum[i]=0;
   
  for(i=1;i<=MAXHIDDENSTATE;i++)
   for(j=GNUM+1;j<=MCAX;j++)
    if(componentnum[j]==i) countnum[i]+=1;
  
  for(i=1;i<=MAXHIDDENSTATE;i++)
   countp[i]=countnum[i]/((MCAX-GNUM)*1.0);
   
  dat3=fopen("estimateresult.txt","a");
   fprintf(dat3,"In the %d repeat,the estimate result of hiddenstate number is:\n",CIR);
    for(i=1;i<=MAXHIDDENSTATE;i++)
     fprintf(dat3,"%d       %d           %lf\n",i,countnum[i],countp[i]);
    fclose(dat3);
    
              
  } /*CIR*/

 
 for(i=1;i<=NO+10000;i++)
  printf("Ok!0k!Ok!0k!Ok!0k!\n");
 
 free_matrix(TRANSPR,1,MAXHIDDENSTATE,1,MAXHIDDENSTATE); 
 free_imatrix(ZID,1,NO,1,NT);
 free_imatrix(ZD,1,NO,1,NT);
 free_f3tensor(LY,1,MAXHIDDENSTATE,1,NY,1,NK);
 free_matrix(MU,1,MAXHIDDENSTATE,1,NY);
 free_matrix(PSX,1,MAXHIDDENSTATE,1,NY);
 free_f3tensor(BI,1,MAXHIDDENSTATE,1,NM,1,NK);
 free_f3tensor(PB,1,MAXHIDDENSTATE,1,NM,1,NZ);
 free_f3tensor(PHI,1,MAXHIDDENSTATE,1,NZ,1,NZ);
 free_f3tensor(PI,1,MAXHIDDENSTATE,1,NM,1,NM);
 free_matrix(PSD,1,MAXHIDDENSTATE,1,NM); 
 free_f3tensor(YO,1,NO,1,NT,1,NY);  
 free_f3tensor(TUE,1,NO,1,NT,1,NK);
 free_ivector(ROY,1,NY);
 free_imatrix(CLY,1,NY,1,NK);
 free_ivector(ROB,1,NM);
 free_imatrix(CLB,1,NM,1,NK);
 free_imatrix(IDY,1,NY,1,NK);
 free_imatrix(IDB,1,NM,1,NK);
 free_vector(hypermu,1,NY);
 free_matrix(PPSG,1,NY,1,NY);
 free_matrix(ma,1,NY,1,NY);   
 free_matrix(mucov,1,NY,1,NY);
 free_matrix(PMU,1,MAXHIDDENSTATE,1,NY); 
 free_f3tensor(PLY,1,MAXHIDDENSTATE,1,NY,1,NK);   
 free_f3tensor(PBI,1,MAXHIDDENSTATE,1,NM,1,NK);                
 free_f3tensor(SIGMA,1,MAXHIDDENSTATE,1,NY,1,NY);
 free_f3tensor(XSIG,1,MAXHIDDENSTATE,1,NK,1,NK);
 free_vector(MID,1,NY);
 free_imatrix(TRANSNUM,1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 free_ivector(COMPONENTNUM,1,MAXHIDDENSTATE);
 free_vector(MSU,1,NK);
 free_f3tensor(XI,1,NO,1,NT,1,NK);
 free_f3tensor(NXI,1,MAXHIDDENSTATE,1,NO*NT,1,NK);
 free_f3tensor(YYO,1,MAXHIDDENSTATE,1,NO*NT,1,NY);
 free_f3tensor(NX1,1,MAXHIDDENSTATE,1,NO*NT,1,NM);
 free_f3tensor(NX2,1,MAXHIDDENSTATE,1,NO*NT,1,NZ);
 free_vector(PROP,1,MAXHIDDENSTATE);
 free_vector(NEYO,1,NO*NT);
 
 free_matrix(ETRANSPR,1,MAXHIDDENSTATE,1,MAXHIDDENSTATE); 
 free_f3tensor(ELY,1,MAXHIDDENSTATE,1,NY,1,NK);
 free_matrix(EMU,1,MAXHIDDENSTATE,1,NY);
 free_matrix(EPSX,1,MAXHIDDENSTATE,1,NY);
 free_f3tensor(EBI,1,MAXHIDDENSTATE,1,NM,1,NK);
 free_f3tensor(EPHI,1,MAXHIDDENSTATE,1,NZ,1,NZ);
 free_matrix(EPSD,1,MAXHIDDENSTATE,1,NM); 
 
 free_vector(generaterandom,1,100);
 free_vector(proposalrandomvalue,1,100);
 free_matrix(SAUXTRANS,1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 free_matrix(MAUXTRANS,1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 free_vector(mergerandom,1,100);
 free_vector(mergerandomnum,1,100);
 free_f3tensor(SAUXLY,1,MAXHIDDENSTATE,1,NY,1,NK);
 free_matrix(SAUXMU,1,MAXHIDDENSTATE,1,NY);
 free_matrix(SAUXPSX,1,MAXHIDDENSTATE,1,NY);
 free_f3tensor(SAUXPB,1,MAXHIDDENSTATE,1,NM,1,NZ);
 free_f3tensor(SAUXPHI,1,MAXHIDDENSTATE,1,NZ,1,NZ);
 free_f3tensor(SAUXPI,1,MAXHIDDENSTATE,1,NM,1,NM);
 free_matrix(SAUXPSD,1,MAXHIDDENSTATE,1,NM); 
 free_imatrix(SAUXZID,1,NO,1,NT);
 free_vector(shapeparameter,1,2);
 
 free_f3tensor(MAUXLY,1,MAXHIDDENSTATE,1,NY,1,NK);
 free_matrix(MAUXMU,1,MAXHIDDENSTATE,1,NY);
 free_matrix(MAUXPSX,1,MAXHIDDENSTATE,1,NY);
 free_f3tensor(MAUXPB,1,MAXHIDDENSTATE,1,NM,1,NZ);
 free_f3tensor(MAUXPHI,1,MAXHIDDENSTATE,1,NZ,1,NZ);
 free_f3tensor(MAUXPI,1,MAXHIDDENSTATE,1,NM,1,NM);
 free_matrix(MAUXPSD,1,MAXHIDDENSTATE,1,NM); 
 free_imatrix(MAUXZID,1,NO,1,NT);
 free_vector(randomvalued,1,100);
 
 free_ivector(componentnum,1,MCAX);
 free_ivector(countnum,1,MAXHIDDENSTATE);
 free_vector(countp,1,MAXHIDDENSTATE);
 }
