#define NO               80    /* NO is sample size */
#define NT               10    
#define REPEATNUM        100       
#define MAXHIDDENSTATE   100         /* the number of max hidden state */
#define REALHIDDENSTATE  2           /* the number of real hidden state */
#define INITHIDDENSTATE  2           /*the number of initial hidden state*/
#define NY       9                /* NY is dimension of y */
#define NK       3                /* NK is dimension of omega, which is partitioned into eta and xi*/
#define NB       3               /* NB is the number of columns of the combined loading matrix in s.e (BI) */
#define NP       100            /* NP is the total number of parameters need to estimate*/
#define NM       1             /* NM is the dimension of eta */
#define NZ       2            /* NZ is the dimension of xi */
#define MCAX     20000        /*iterations*/
#define GNUM     10000         /*burn-in*/
#define PPD      0.0
#define PALPA      6.0
#define PBETA      4.0
#define PAL      6.0
#define PBE      4.0
#define RHO      8
#define RH      8.0
#define DERI    1.0
