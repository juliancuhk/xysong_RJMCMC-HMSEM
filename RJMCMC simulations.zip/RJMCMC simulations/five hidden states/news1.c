void  news1(int k, int zc, int **CLB, int *NUM, double ***NXI, double ***BI, double *NEYO, double ***PBI, double **PSD,int *ROB)
	 {
	    int    i, j, m,n;
	    long   radom;
	    double  AA, AK;
	    double **imaf,**SIMG,*AMU,*PP,*XX;
	    imaf=matrix(1,NK,1,NK);
	    SIMG=matrix(1,NK,1,NK);
	    AMU=vector(1,NK);
	    PP=vector(1,NK);
	    XX=vector(1,NK);


	   for(i=1;i<=NK;i++)
	       for(j=1;j<=NK;j++){
		 SIMG[i][j]=0.0;
		 for(m=1;m<=NUM[zc];m++)
		 SIMG[i][j]+=NXI[zc][m][i]*NXI[zc][m][j];
		  }

	   for(i=1;i<=ROB[k]; i++){
	       /*AMU[i]=PBI[zc][k][i];*/
	       n=CLB[k][i];
	       AMU[i]=PBI[zc][k][n];
	       for(m=1; m<=NUM[zc];m++)
	          AMU[i]+=NEYO[m]*NXI[zc][m][n];
       }
	   for(i=1;i<=ROB[k];i++)
          for(j=1;j<=ROB[k];j++){
		      m=CLB[k][i];
		      n=CLB[k][j];
		      imaf[i][j]=SIMG[m][n];
		      if(i==j) imaf[i][j]+=1.0;    
          }

       if(ROB[k]>0) iv(imaf, ROB[k]+1);

       for(i=1;i<=ROB[k];i++)
          for(j=1;j<=ROB[k];j++)
              SIMG[i][j]=imaf[i][j]; 

       choldc(imaf, ROB[k], PP);
	   for(m=1; m<=ROB[k];m++)
	      for(i=m;i<=ROB[k];i++){
	         if(i==m)  imaf[m][i]=PP[m];
	         else   imaf[m][i]=0.0;
	      }

       AK=PBE;
	   for(i=1;i<=NUM[zc];i++)
	      AK+=0.5*NEYO[i]*NEYO[i];
       for(i=1;i<=ROB[k];i++){
          n=CLB[k][i];
          AK+=0.5*PBI[zc][k][i]*PBI[zc][k][i];
       }
	   for(i=1;i<=ROB[k];i++){
	      XX[i]=0.0;
	      for(j=1;j<=ROB[k];j++)
		     XX[i]+=SIMG[i][j]*AMU[j];
	      AK-=0.5*AMU[i]*XX[i];
       }

	   m=NUM[zc]/2+PAL;
        do{       
          radom=rand();
 	      if(NUM[zc]%2==0)
	         PSD[zc][k]=AK/gamdev(m,&radom);
	      else{
             AA=gasdev(&radom);
	         radom=rand();
	         PSD[zc][k]=AK/(gamdev(m,&radom)+0.5*AA*AA);
	      }
       }while(PSD[zc][k]<=PPD);
	   
       for(i=1;i<=ROB[k];i++){
          radom=rand();
	      PP[i]=gasdev(&radom);
       }
	   
       for(i=1;i<=ROB[k];i++)
   	      for(j=1;j<=ROB[k];j++)
		     XX[i]+=sqrt(PSD[zc][k])*imaf[i][j]*PP[j];

	   for(i=1;i<=ROB[k];i++){
		   m=CLB[k][i];
		   BI[zc][k][m]=XX[i];
       }

	   free_matrix(imaf,1,NK,1,NK);
	   free_matrix(SIMG,1,NK,1,NK);
       free_vector(AMU,1,NK);
       free_vector(PP,1,NK);
       free_vector(XX,1,NK);

}/*end of newsy.c */
