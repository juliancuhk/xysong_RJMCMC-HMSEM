void  rel1(int currentNC,double ***BI, double ***PB, double ***PI)
{
int i, j, k;

for(k=1; k<=currentNC; k++)
 for(i=1; i<=NM; i++){
    for(j=1; j<=NM; j++)
       PI[k][i][j]=BI[k][i][j];
    for(j=1; j<=NZ; j++)
       PB[k][i][j]=BI[k][i][j+NM];
  }

}/* end */
