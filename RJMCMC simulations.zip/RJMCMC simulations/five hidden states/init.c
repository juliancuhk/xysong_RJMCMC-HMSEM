#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>

#include "fac.c"

init(int **ZID,double ***PB,double ***PI,double ***PHI,double **PSD,double ***TUE)
{
 int i,j,k,m,n,s,g;
 double d;
 long random;
 int *indx;
 double ***xi2,**fma,*delta;
 xi2=f3tensor(1,NO,1,NT,1,NZ);
 fma=matrix(1,NM,1,NM);
 indx=ivector(1,NM);
 delta=vector(1,NM);
 
 
 
 
 fac(ZID,PHI,xi2);    /*generate xi2~N(0,PHI)*/ 
 
 
 
 for(i=1;i<=NO;i++)
  for(j=1;j<=NT;j++)
   {
    for(m=1;m<=NM;m++)
     for(n=1;n<=NM;n++)
      {fma[m][n]=-PI[ZID[i][j]][m][n];
        if(n==m) fma[m][n]+=1.0;}
        
        ludcmp(fma,NM,indx,&d);
         
         for(k=1;k<=NZ;k++)
          TUE[i][j][k+NM]=xi2[i][j][k];
          
           for(k=1;k<=NM;k++)
            {random=rand();
             delta[k]=gasdev(&random)*sqrt(PSD[ZID[i][j]][k]);
              for(s=1;s<=NZ;s++)
               delta[k]+=PB[ZID[i][j]][k][s]*xi2[i][j][s];
              }
              
             
              
              lubksb(fma,NM,indx,delta);   /*generate the latent variable eta*/ 
              
             
              for(g=1;g<=NM;g++)
               TUE[i][j][g]=delta[g];
        
             
                    }
 
 free_f3tensor(xi2,1,NO,1,NT,1,NZ);
 free_matrix(fma,1,NM,1,NM);
 free_ivector(indx,1,NM);
 free_vector(delta,1,NM);
 }
