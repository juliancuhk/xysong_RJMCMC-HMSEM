#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>

double randombeta(double a,double b)
{ double u,v;
  double x,y;
  long random1,random2;
  
  do
  {
   random1=rand();
   u=ran2(&random1);
   random2=rand();
   v=ran2(&random2);
   x=pow(u,1/a);
   y=pow(v,1/b); 
       }while(x+y>1);
  
  return x/(x+y);
  }
