#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>

float jumprate(int currentNC,int proposalNC)
{ float p;
 if(currentNC==2||currentNC==MAXHIDDENSTATE) p=1.0;
  else p=0.5;
  
  return p;
  }
