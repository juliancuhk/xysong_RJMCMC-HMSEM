void readtransmatrix(double **TRANSPR)
{FILE *dat1;
 int i,j,k;
 
 dat1=fopen("truetrans.dat","r");
  
  for(i=1;i<=REALHIDDENSTATE;i++)
   for(j=1;j<=REALHIDDENSTATE;j++)
     fscanf(dat1,"%lf",&TRANSPR[i][j]);
      fclose(dat1);
   
 }
