stationaryvector(int N,double **M,double *V)
{int i,j,g,t;
 double *initv, *b;
 initv=vector(1,MAXHIDDENSTATE);
 b=vector(1,MAXHIDDENSTATE);
 
 initv[1]=1;
 for(t=2;t<=N;t++)  initv[t]=0.0;
 
 for(g=1;g<=5000;g++)
  { for(j=1;j<=N;j++)
     {b[j]=0.0;
      for(i=1;i<=N;i++)
       b[j]+=initv[i]*M[i][j];}
       for(t=1;t<=N;t++)
        initv[t]=b[t];
      }
      
  for(t=1;t<=N;t++)
   V[t]=initv[t];
      
 free_vector(initv,1,MAXHIDDENSTATE);
 free_vector(b,1,MAXHIDDENSTATE);      
}
