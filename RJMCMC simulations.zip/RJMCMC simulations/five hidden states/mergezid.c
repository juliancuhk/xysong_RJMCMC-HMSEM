mergezid(int currenthiddenstate,int proposalhiddenstate,int mergenum,int **ZID,int **MAUXZID)
{int i,j;
  
  for(i=1;i<=NO;i++)
   for(j=1;j<=NT;j++)
   {if(ZID[i][j]<mergenum) MAUXZID[i][j]=ZID[i][j];
   else if(ZID[i][j]>mergenum+1) MAUXZID[i][j]=ZID[i][j]-1;
   else MAUXZID[i][j]=mergenum; }
   
   }
