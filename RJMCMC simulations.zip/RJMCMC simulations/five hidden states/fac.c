fac(int **ZID, double ***PHI, double ***TZT)
{
 int i,j,k,m,n,f,g,s;
 long random1;
 double **INPH, *diag;
 INPH=matrix(1,NZ,1,NZ);
 diag=vector(1,NZ);
 
  
  for(i=1;i<=NO;i++)
   for(j=1;j<=NT;j++)
    {
  
      for(m=1;m<=NZ;m++)
       for(n=1;n<=NZ;n++)
        INPH[m][n]=PHI[ZID[i][j]][m][n];
        
        
        choldc(INPH,NZ,diag);
        
         
         for(f=1;f<=NZ;f++)
          for(g=f;g<=NZ;g++)
           if(g==f) INPH[f][g]=diag[f];
            else    INPH[f][g]=0.0;
            
           
            for(k=1;k<=NZ;k++)
             {random1=rand();
              diag[k]=gasdev(&random1);}
              
              
              for(s=1;s<=NZ;s++)
               {TZT[i][j][s]=0.0;
                 for(k=1;k<=NZ;k++)
                  TZT[i][j][s]+=INPH[s][k]*diag[k];}
                     
                     
          }
 

 
 free_matrix(INPH,1,NZ,1,NZ);
 free_vector(diag,1,NZ);
 }
