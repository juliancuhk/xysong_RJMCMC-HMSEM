void changeparameters(int currentNC,double **TRANSPR,double **SAUXTRANS,double **MU,double **SAUXMU,double ***LY,double ***SAUXLY,double ***PHI,double ***SAUXPHI,double **PSD,double **SAUXPSD,double **PSX,double **SAUXPSX,double ***PB,double ***SAUXPB,double ***PI,double ***SAUXPI)
{int i,j,k;
 
 for(i=1;i<=currentNC;i++)
  for(j=1;j<=currentNC;j++)
  TRANSPR[i][j]=SAUXTRANS[i][j];
  
 for(i=1;i<=currentNC;i++)
  for(j=1;j<=NY;j++)
   MU[i][j]=SAUXMU[i][j];
   
 for(i=1;i<=currentNC;i++)
  for(j=1;j<=NY;j++)
   for(k=1;k<=NK;k++)
    LY[i][j][k]=SAUXLY[i][j][k];
    
 for(i=1;i<=currentNC;i++)
  for(j=1;j<=NZ;j++)
   for(k=1;k<=NZ;k++)
    PHI[i][j][k]=SAUXPHI[i][j][k];
 
 for(i=1;i<=currentNC;i++)
  for(j=1;j<=NM;j++)
   PSD[i][j]=SAUXPSD[i][j];
   
 for(i=1;i<=currentNC;i++)
  for(j=1;j<=NY;j++)
   PSX[i][j]=SAUXPSX[i][j];
 
 for(i=1;i<=currentNC;i++)
  for(j=1;j<=NM;j++)
   for(k=1;k<=NZ;k++)
    PB[i][j][k]=SAUXPB[i][j][k];
    
 for(i=1;i<=currentNC;i++)
  for(j=1;j<=NM;j++)
   for(k=1;k<=NM;k++)
    PI[i][j][k]=SAUXPI[i][j][k];
 
 }
