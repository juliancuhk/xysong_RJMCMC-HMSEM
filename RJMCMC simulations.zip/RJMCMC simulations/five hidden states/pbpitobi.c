void pbpitobi(int currentNC,double ***PB,double ***PI,double ***BI)
{int i, j, k;

  for(k=1;k<=currentNC;k++)
     for(i=1; i<=NM; i++){
        for(j=1; j<=NM; j++)
           BI[k][i][j]=PI[k][i][j];
        for(j=1; j<=NZ; j++)
           BI[k][i][j+NM]=PB[k][i][j];
  }
  
}
