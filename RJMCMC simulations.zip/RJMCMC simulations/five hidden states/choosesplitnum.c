#include<stdio.h>
#include <stdlib.h>
#include <math.h>

int choosesplitnum(int k)
{ int ra;
 long random;
 double unfm,*p; 
 float a;
 ra=k;
 a=1.0/ra;
 p=vector(1,ra);
 int i;
 int s,d;
 for(i=1;i<=ra;i++)
  p[i]=i*a;
  random=rand();
  unfm=ran2(&random);
 for(s=1;s<=ra&&unfm>p[s];s++)
    ;
    d=s;
    return d;
    
 free_vector(p,1,ra);
      }
