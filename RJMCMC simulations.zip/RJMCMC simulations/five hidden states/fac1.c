void fac1(int zc, double *GP, double ***PH)
 {
     double **INPH,*diag;
     
     int    i, j, k;
     long   radom;
     
     INPH=matrix(1,NK,1,NK);
     diag=vector(1,NK);
    
     for(i=1; i<=NK; i++)
        for(j=1; j<=NK; j++)
           INPH[i][j]=PH[zc][i][j];
  
     choldc(INPH, NK, diag);
     for(k=1; k<=NK; k++)
        for(j=k; j<=NK; j++)
	   if(j==k)  INPH[k][j]=diag[k];
	   else      INPH[k][j]=0.0;

     for(j=1;j<=NK;j++){
         radom=rand(); 
         diag[j]=gasdev(&radom);
      }   

     for(j=1;j<=NK;j++){
        GP[j]=0.0;
        for(k=1;k<=NK;k++)
           GP[j]+=INPH[j][k]*diag[k];
      }

    free_matrix(INPH,1,NK,1,NK);  
    free_vector(diag,1,NK);

    }/* end */
