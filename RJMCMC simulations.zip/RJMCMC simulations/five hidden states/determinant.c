double determinant(double **W,int N)
{
 double **a,d,b;
 int i,j,*index;
 a=matrix(1,N,1,N);
 index=ivector(1,N);
 
 for(i=1;i<=N;i++)
  for(j=1;j<=N;j++)
   a[i][j]=W[i][j];
   
 ludcmp(a,N,index,&d);
  
 for(j=1;j<=N;j++)
  d*=a[j][j];
 
 b=d;
 
 free_matrix(a,1,N,1,N);
 free_ivector(index,1,N);
 
 return b;
       }
