splitprobabilitymatrix(int currenthiddenstate,int proposalhiddenstate,int splitnum,double **TRANSPR,double **SAUXTRANS,double *generaterandom,double *shapeparameter)
{
 int i,j,k,m,n;
 double *PROP,sumpr,trandom,*rowrandom,*colrandom,trandom1,r,s,ca,suma1,suma2,suma3,trlittle,trlarge,sumb1,sumc1,sumc2;
 long random1;
 
 PROP=vector(1,MAXHIDDENSTATE);
 rowrandom=vector(1,MAXHIDDENSTATE);
 colrandom=vector(1,MAXHIDDENSTATE);
 
 ca=0.50;
 trandom=randombeta(2,2);
 
 stationaryvector(currenthiddenstate,TRANSPR,PROP);          /*calculate stationary probability of a transition matrix*/ 
 
 if(trandom>0.5)
 {s=(1-(1-trandom)*(1+ca))/ca;
  r=s*trandom/(1-trandom);}
 else
 {r=(1-trandom*(1+ca))/ca;
  s=r*(1-trandom)/trandom;}
  
 
       for(m=1;m<currenthiddenstate;m++)
        rowrandom[m]=randombeta(r,s);
       for(n=1;n<currenthiddenstate;n++)
        colrandom[n]=randombeta(r,s);
  
        
      for(i=1;i<splitnum;i++)
       {for(j=1;j<splitnum;j++) SAUXTRANS[i][j]=TRANSPR[i][j];
        SAUXTRANS[i][splitnum]=rowrandom[i]*TRANSPR[i][splitnum];
        SAUXTRANS[i][splitnum+1]=(1-rowrandom[i])*TRANSPR[i][splitnum];
        for(j=splitnum+2;j<=proposalhiddenstate;j++) SAUXTRANS[i][j]=TRANSPR[i][j-1];}
      for(i=splitnum+2;i<=proposalhiddenstate;i++)
       {for(j=1;j<splitnum;j++) SAUXTRANS[i][j]=TRANSPR[i-1][j];
        SAUXTRANS[i][splitnum]=rowrandom[i-2]*TRANSPR[i-1][splitnum];
        SAUXTRANS[i][splitnum+1]=(1-rowrandom[i-2])*TRANSPR[i-1][splitnum];
        for(j=splitnum+2;j<=proposalhiddenstate;j++) SAUXTRANS[i][j]=TRANSPR[i-1][j-1];} 
        
      for(j=1;j<splitnum;j++) SAUXTRANS[splitnum][j]=colrandom[j]*TRANSPR[splitnum][j]/trandom;
      for(j=1;j<splitnum;j++) SAUXTRANS[splitnum+1][j]=(1-colrandom[j])*TRANSPR[splitnum][j]/(1-trandom);
      for(j=splitnum+2;j<=proposalhiddenstate;j++) SAUXTRANS[splitnum][j]=colrandom[j-2]*TRANSPR[splitnum][j-1]/trandom;
      for(j=splitnum+2;j<=proposalhiddenstate;j++) SAUXTRANS[splitnum+1][j]=(1-colrandom[j-2])*TRANSPR[splitnum][j-1]/(1-trandom);
      
      suma1=0.0;
      for(i=1;i<splitnum;i++) suma1+=PROP[i]*SAUXTRANS[i][splitnum]/(PROP[splitnum]*trandom);
      for(i=splitnum+2;i<=proposalhiddenstate;i++) suma1+=PROP[i-1]*SAUXTRANS[i][splitnum]/(PROP[splitnum]*trandom);
      suma2=0.0;
      for(i=1;i<splitnum;i++) suma2+=SAUXTRANS[splitnum][i];
      for(i=splitnum+2;i<=proposalhiddenstate;i++) suma2+=SAUXTRANS[splitnum][i];
      trlittle=1-(1-suma1)/(1-suma2);
      if(trlittle<0) trlittle=0.0;
      suma3=0.0;
      for(i=1;i<splitnum;i++) suma3+=SAUXTRANS[splitnum+1][i];
      for(i=splitnum+2;i<=proposalhiddenstate;i++) suma3+=SAUXTRANS[splitnum+1][i];
      trlarge=1-(1-suma1-((1-trandom)*(1-suma3)/trandom))/(1-suma2);
      if(trlarge>1) trlarge=1.0;
      
      if(trlarge>trlittle)
      {random1=rand();
      trandom1=ran2(&random1);
      trandom1=trlittle+trandom1*(trlarge-trlittle);
      
      sumb1=0.0;
      for(i=1;i<splitnum;i++) sumb1+=SAUXTRANS[splitnum][i];
      for(i=splitnum+2;i<=proposalhiddenstate;i++) sumb1+=SAUXTRANS[splitnum][i];
      SAUXTRANS[splitnum][splitnum+1]=trandom1*(1-sumb1);
      SAUXTRANS[splitnum][splitnum]=(1-trandom1)*(1-sumb1);
      
      sumc1=0.0;
      for(i=1;i<splitnum;i++) sumc1+=colrandom[i]*TRANSPR[splitnum][i];
      for(i=splitnum+1;i<=currenthiddenstate;i++) sumc1+=colrandom[i-1]*TRANSPR[splitnum][i];
      sumc2=0.0;
      for(i=1;i<splitnum;i++) sumc2+=PROP[i]*rowrandom[i]*TRANSPR[i][splitnum]/PROP[splitnum];
      for(i=splitnum+1;i<=currenthiddenstate;i++) sumc2+=PROP[i]*rowrandom[i-1]*TRANSPR[i][splitnum]/PROP[splitnum];
      SAUXTRANS[splitnum+1][splitnum]=((1-trandom1)*sumc1+trandom*trandom1-sumc2)/(1-trandom);
      
      SAUXTRANS[splitnum+1][splitnum+1]=1.0;
      for(i=1;i<=splitnum;i++) SAUXTRANS[splitnum+1][splitnum+1]-=SAUXTRANS[splitnum+1][i];
      for(i=splitnum+2;i<=proposalhiddenstate;i++) SAUXTRANS[splitnum+1][splitnum+1]-=SAUXTRANS[splitnum+1][i];}
      else 
      {for(i=1;i<=proposalhiddenstate;i++)
        for(j=1;j<=proposalhiddenstate;j++)
           SAUXTRANS[i][j]=100;}
      
      
      generaterandom[1]=trandom;
      for(i=1;i<currenthiddenstate;i++) generaterandom[i+1]=rowrandom[i];
      for(j=1;j<currenthiddenstate;j++) generaterandom[j+currenthiddenstate]=colrandom[j];
      
    shapeparameter[1]=r;
    shapeparameter[2]=s;  
  
 free_vector(PROP,1,MAXHIDDENSTATE);
 free_vector(rowrandom,1,MAXHIDDENSTATE);
 free_vector(colrandom,1,MAXHIDDENSTATE);
 
 }
