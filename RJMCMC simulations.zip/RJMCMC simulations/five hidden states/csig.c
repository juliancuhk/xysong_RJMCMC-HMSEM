csig(int currenthiddenstate, double ***LY, double ***PB, double ***PHI, double ***PI, double **PSD, double **PSX, double ***SIGMA, double ***XSIG)
{
    int i, j, k, m, zc;
    
    double d;
    int *indx;
    double **fma,**SG,*col,**ipi,**p2;
    fma=matrix(1,NY,1,NY);
    SG=matrix(1,NY,1,NY); 
    indx=ivector(1,NM);
    col=vector(1,NM);
    ipi=matrix(1,NM,1,NM); 
    p2=matrix(1,NM,1,NZ); 
    
    

    for(zc=1; zc<=currenthiddenstate; zc++){
       for(i=1; i<=NM; i++)
          for(j=1; j<=NM; j++){
            fma[i][j]=-PI[zc][i][j];
            if(i==j) fma[i][j]+=1.0;
        }
        
        
        
       ludcmp(fma, NM, indx, &d);
       
      
         
       for(i=1; i<=NM; i++){
          for(j=1; j<=NM; j++) col[j]=0.0;
          col[i]=1.0;
          lubksb(fma, NM, indx, col); 
          for(j=1; j<=NM; j++) ipi[j][i]=col[j];
        }  /* ipi=inv(I-PI)*/
        
        
         
       for(i=1; i<=NM; i++)
         for(j=1; j<=NZ; j++){
           p2[i][j]=0.0;
           for(k=1; k<=NM; k++)
             for(m=1; m<=NZ; m++)
                p2[i][j]+=ipi[i][k]*PB[zc][k][m]*PHI[zc][m][j];
                /*p2=inv(I-PI)*PB*PHI*/
           XSIG[zc][i][j+NM]=p2[i][j];
           XSIG[zc][j+NM][i]=p2[i][j];           
         } 
         
         
         
        for(i=1; i<=NZ; i++)
          for(j=1; j<=NZ; j++)
             XSIG[zc][i+NM][j+NM]=PHI[zc][i][j]; 
             
             
             
        for(i=1; i<=NM; i++)
          for(j=1; j<=NM; j++){
             fma[i][j]=0.0;
             for(k=1; k<=NZ; k++)
                for(m=1; m<=NM; m++)
                   fma[i][j]+=p2[i][k]*PB[zc][m][k]*ipi[j][m];
             for(k=1; k<=NM; k++)    
                fma[i][j]+=ipi[i][k]*PSD[zc][k]*ipi[j][k];
             XSIG[zc][i][j]=fma[i][j];
	      }
           /*fma=Inv(I-PI)*PB*PHI*PB'*inv(I-PI)'+Inv(I-PI)*PSD*Inv(I-PI)' */
           /*XSIG is the covariance structure of xi(omega), Cov(xi,xi)*/	  
       
         
       for(i=1; i<=NY; i++)
	      for(j=1; j<=NY; j++){
	         fma[i][j]=0.0;
	         for(k=1; k<=NK; k++)
	            for(m=1; m<=NK; m++)
		           fma[i][j]+=LY[zc][i][k]*XSIG[zc][k][m]*LY[zc][j][m];
	         if(i==j)  fma[i][j]+=PSX[zc][i];
          }
       /* fma=LY*Cov(xi,xi)*LY'+PSX is the covariance structure of y, Cov(y,y) */   
       
       
         
       iv(fma, NY+1);
       
      
       
       for(i=1; i<=NY; i++)
          for(j=1; j<=NY; j++)
              SIGMA[zc][i][j]=fma[i][j];
       /* SIGMA=Inv(LY*Cov(xi,xi)*LY'+PSX)=Inv(Cov(y,y))*/ 
        
       for(i=1; i<=NK; i++)
         for(j=1; j<=NK; j++)
            fma[i][j]=XSIG[zc][i][j];
       /* fma=Cov(xi,xi)*/
       
       
       iv(fma, NK+1);
       for(i=1; i<=NK; i++)
         for(j=1; j<=NK; j++)
           XSIG[zc][i][j]=fma[i][j];
       /*XSIG=Inv(Cov(xi,xi))*/    
         
       for(i=1; i<=NK; i++)
         for(j=1; j<=NK; j++)
            for(k=1; k<=NY; k++)
               XSIG[zc][i][j]+=LY[zc][k][i]*LY[zc][k][j]/PSX[zc][k];
       /*Inv(Cov(xi,xi))+LY'*Inv(PSX)*LY */        
          
       for(i=1; i<=NK; i++)
         for(j=1; j<=NK; j++)
            fma[i][j]=XSIG[zc][i][j];
         
          
         
          
             
       iv(fma, NK+1);
       
       for(i=1; i<=NK; i++)
         for(j=1; j<=NK; j++)
           XSIG[zc][i][j]=fma[i][j];
        /*XSIG=Inv(Inv(Cov(xi,xi))+LY'*Inv(PSX)*LY)*/  
        /* used in the posterior of xi */  
         
    }/* zc */

     
      free_matrix(fma,1,NY,1,NY);
      free_ivector(indx,1,NM);
      free_matrix(SG,1,NY,1,NY);
      free_vector(col,1,NM);
      free_matrix(ipi,1,NM,1,NM);
      free_matrix(p2,1,NM,1,NZ);
 
}/* end */
