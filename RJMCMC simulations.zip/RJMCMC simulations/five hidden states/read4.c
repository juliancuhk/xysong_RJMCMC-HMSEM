void read4(double ***BI, double ***PB, double ***PBI, double ***PHI, double ***PI, double **PSD)
{int i,j,k;
 FILE *dat;
 
 dat=fopen("int2.dat","r");
  
  for(k=1;k<=INITHIDDENSTATE;k++)
   for(i=1;i<=NM;i++)
    for(j=1;j<=NM;j++)
     fscanf(dat,"%lf",&PI[k][i][j]);
     
  for(k=1;k<=INITHIDDENSTATE;k++)
   for(i=1;i<=NM;i++)
    for(j=1;j<=NZ;j++)
     fscanf(dat,"%lf",&PB[k][i][j]); 
     
   for(i=1;i<=NM;i++)
    for(j=1;j<=NK;j++)
     fscanf(dat,"%lf",&PBI[1][i][j]); 
     
  for(k=1;k<=INITHIDDENSTATE;k++)
   for(i=1;i<=NZ;i++)
    for(j=1;j<=NZ;j++)
     fscanf(dat,"%lf",&PHI[k][i][j]); 
    
  for(k=1;k<=INITHIDDENSTATE;k++)
   for(i=1;i<=NM;i++) 
    fscanf(dat,"%lf",&PSD[k][i]);
    
   fclose(dat);

  for(k=1;k<=INITHIDDENSTATE;k++)
   for(i=1;i<=NM;i++)
    for(j=1;j<=NM;j++)
     BI[k][i][j]=PI[k][i][j];
     
  for(k=1;k<=INITHIDDENSTATE;k++)
   for(i=1;i<=NM;i++)
    for(j=1;j<=NZ;j++)
     BI[k][i][j+NM]=PB[k][i][j];   
     
   for(k=2;k<=MAXHIDDENSTATE;k++)
    for(i=1;i<=NM;i++)
     for(j=1;j<=NK;j++)
      PBI[k][i][j]=PBI[1][i][j];
 }
