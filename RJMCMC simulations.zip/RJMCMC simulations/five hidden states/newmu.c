void newmu(int zc, double ***ETA, double ***LY, double **MU, int *NUM, double **pmu, double **PSG, double **PSI, double ***YYO)
    {
      int i, j, k;
      long radom;
      float  mmu; 
      double **fma,*zmu;
      fma=matrix(1,NY,1,NY);
      zmu=vector(1,NY);
    
      for(i=1;i<=NY;i++){
         MU[zc][i]=0.0;
         for(j=1;j<=NUM[zc];j++){
            mmu=YYO[zc][j][i];
            for(k=1;k<=NK;k++)
               mmu-=LY[zc][i][k]*ETA[zc][j][k];
            MU[zc][i]+=mmu; 
         }
         MU[zc][i]=MU[zc][i]/PSI[zc][i];
         for(k=1; k<=NY; k++)
             MU[zc][i]+=PSG[i][k]*pmu[zc][k];
       }/* i */
       /* inv(PSI)*sum(y-LY*omega)+inv(SIG0)*MU0 */
       /* PSG=inv(SIG0), pmu=MU0 */

       for(k=1; k<=NY; k++)
          for(j=1; j<=NY; j++){
            fma[k][j]=PSG[k][j];
            if(j==k) fma[k][j]+=NUM[zc]/PSI[zc][k];
          }
       /* fma=inv(SIG0)+n_k*inv(PSI) */   
          
       iv(fma, NY+1); 
       /* fma=inv*(inv(SIG0)+n_k*inv(PSI)) */
       
       for(i=1; i<=NY; i++){
          zmu[i]=0.0; 
          for(k=1; k<=NY; k++)
             zmu[i]+=fma[i][k]*MU[zc][k];
       }
       
       for(i=1; i<=NY; i++)
          MU[zc][i]=zmu[i];
       /* MU=inv(inv(SIG0)+n_k*inv(PSI))* (inv(PSI)*sum(y-LY*omega)+inv(SIG0)*MU0)*/
       
       choldc(fma, NY, zmu);
       for(k=1; k<=NY; k++) 
          for(j=k; j<=NY; j++)
             if(j==k)  fma[k][j]=zmu[k];
             else     fma[k][j]=0.0;
       for(j=1; j<=NY; j++){
            radom=rand(); 
            zmu[j]=gasdev(&radom);
          }
       
       for(i=1; i<=NY; i++)
          for(k=1; k<=NY; k++)
             MU[zc][i]+=fma[i][k]*zmu[k];
     
       free_matrix(fma,1,NY,1,NY);
       free_vector(zmu,1,NY);

 }/* end of newmu.c */

