double acceptmergeprobability(int currenthiddenstate,int proposalhiddenstate,int mergenum,int **ZID,int **MAUXZID,double ***YO,double **TRANSPR,double **MAUXTRANS,double **MU,double **MAUXMU,double ***LY,double ***MAUXLY,double **PSX,double **MAUXPSX,double ***PB,double ***MAUXPB,double ***PI,double ***MAUXPI,double **PSD,double **MAUXPSD,double ***PHI,double ***MAUXPHI,double *mergerandom,double *randomvalued,double ***XI,double *hypermu,double **mucov,double *shapeparameter)
{int i,j,k,m,n;
 double jumpratio,transprratio,muratio,lyratio,psxratio,pbratio,piratio,psdratio,phiratio;
 double mujacobian,lyjacobian,psxjacobian,pijacobian,pbjacobian,psdjacobian,phijacobian;
 double likelyhoodratio,f1,f2,a1,a2,b1,b2,c;
 double g11,g13,g14,g15,g16,fly1,fly2,fly3,fly4,fly5,fly6,fly7,fly8,fly9,fly10,fly11,g31,g32,g33,g34,g35,g36,g41,g42,g43,g44,g45,g51,g52,g53,g54,g55,g56,f41,f42,f43,f44,f45,f46,f47,f48,f49,f53,f54,f55,f56;
 double acceptrate1,acceptrate2,acceptrate;
 double *va,**mb,*psxpr,*psdpr,**w,*randompra,*randomprb;
 va=vector(1,NY);
 mb=matrix(1,NY,1,NY);
 psxpr=vector(1,NY);
 psdpr=vector(1,NM);
 w=matrix(1,NZ,1,NZ);
 randompra=vector(1,100);
 randomprb=vector(1,100);
 FILE *dat;
 
 likelyhoodratio=1.0;
 for(i=1;i<=NO;i++)
  for(j=1;j<=NT;j++)
   {f1=0;
    f2=0;
    
    for(m=1;m<=NY;m++)
    {a1=YO[i][j][m]-MU[ZID[i][j]][m];
     for(n=1;n<=NK;n++) a1-=LY[ZID[i][j]][m][n]*XI[i][j][n];
     f1-=0.5*log(PSX[ZID[i][j]][m])+0.5*a1*a1/PSX[ZID[i][j]][m];}
     b1=exp(f1);
     
    for(m=1;m<=NY;m++)
    {a2=YO[i][j][m]-MAUXMU[MAUXZID[i][j]][m];
     for(n=1;n<=NK;n++) a2-=MAUXLY[MAUXZID[i][j]][m][n]*XI[i][j][n];
     f2-=0.5*log(MAUXPSX[MAUXZID[i][j]][m])+0.5*a2*a2/MAUXPSX[MAUXZID[i][j]][m];}
     b2=exp(f2);
     c=b2/b1;
     likelyhoodratio*=c;}
     
 jumpratio=jumprate(proposalhiddenstate,currenthiddenstate)/jumprate(currenthiddenstate,proposalhiddenstate);
 
 transprratio=calculatetransprratio(currenthiddenstate,proposalhiddenstate);
 
 g11=pow(3.1415926*2,NY/2)*sqrt(determinant(mucov,NY));
 for(i=1;i<=NY;i++)
   for(j=1;j<=NY;j++)
    mb[i][j]=mucov[i][j];
  iv(mb,NY+1);
 for(i=1;i<=NY;i++)
  va[i]=MAUXMU[mergenum][i]-hypermu[i];
  g13=calculatematrix(va,mb);
 for(i=1;i<=NY;i++)
  va[i]=MU[mergenum][i]-hypermu[i];
  g14=calculatematrix(va,mb);
 for(i=1;i<=NY;i++)
  va[i]=MU[mergenum+1][i]-hypermu[i];
  g15=calculatematrix(va,mb);
 g16=exp(-0.5*(g13-g14-g15));
 muratio=g11*g16;                        /*MU prior ratio*/
 
 fly1=normaldistributionpdf(MAUXLY[mergenum][2][1],0,MAUXPSX[mergenum][2])/((normaldistributionpdf(LY[mergenum][2][1],0,PSX[mergenum][2]))*(normaldistributionpdf(LY[mergenum+1][2][1],0,PSX[mergenum+1][2])));
 fly2=normaldistributionpdf(MAUXLY[mergenum][3][1],0,MAUXPSX[mergenum][3])/((normaldistributionpdf(LY[mergenum][3][1],0,PSX[mergenum][3]))*(normaldistributionpdf(LY[mergenum+1][3][1],0,PSX[mergenum+1][3])));
 fly3=normaldistributionpdf(MAUXLY[mergenum][5][2],0,MAUXPSX[mergenum][5])/((normaldistributionpdf(LY[mergenum][5][2],0,PSX[mergenum][5]))*(normaldistributionpdf(LY[mergenum+1][5][2],0,PSX[mergenum+1][5])));
 fly4=normaldistributionpdf(MAUXLY[mergenum][6][2],0,MAUXPSX[mergenum][6])/((normaldistributionpdf(LY[mergenum][6][2],0,PSX[mergenum][6]))*(normaldistributionpdf(LY[mergenum+1][6][2],0,PSX[mergenum+1][6])));
 fly5=normaldistributionpdf(MAUXLY[mergenum][8][3],0,MAUXPSX[mergenum][8])/((normaldistributionpdf(LY[mergenum][8][3],0,PSX[mergenum][8]))*(normaldistributionpdf(LY[mergenum+1][8][3],0,PSX[mergenum+1][8])));
 fly6=normaldistributionpdf(MAUXLY[mergenum][9][3],0,MAUXPSX[mergenum][9])/((normaldistributionpdf(LY[mergenum][9][3],0,PSX[mergenum][9]))*(normaldistributionpdf(LY[mergenum+1][9][3],0,PSX[mergenum+1][9])));
 lyratio=fly1*fly2*fly3*fly4*fly5*fly6;                     /*LY prior ratio*/
 
 for(i=1;i<=NY;i++)
 {g31=exp(gammln(PALPA));
  g32=pow(PBETA,PALPA);
  g33=PSX[mergenum][i]*PSX[mergenum+1][i]/MAUXPSX[mergenum][i];
  g34=pow(g33,PALPA-1);
  g35=1/PSX[mergenum][i]+1/PSX[mergenum+1][i]-1/MAUXPSX[mergenum][i];
  g36=exp(PBETA*g35);
  psxpr[i]=g31*g34*g36/g32;}
  psxratio=1.0;
  for(i=1;i<=NY;i++)
  psxratio*=psxpr[i];      /*PSX prior rate*/
 
 g41=normaldistributionpdf(MAUXPB[mergenum][1][1],0,MAUXPSD[mergenum][1])/((normaldistributionpdf(PB[mergenum][1][1],0,PSD[mergenum][1]))*(normaldistributionpdf(PB[mergenum+1][1][1],0,PSD[mergenum+1][1])));
 g42=normaldistributionpdf(MAUXPB[mergenum][1][2],0,MAUXPSD[mergenum][1])/((normaldistributionpdf(PB[mergenum][1][2],0,PSD[mergenum][1]))*(normaldistributionpdf(PB[mergenum+1][1][2],0,PSD[mergenum+1][1])));
 pbratio=g41*g42;                /*pb prior ratio*/ 
 
 for(i=1;i<=NM;i++)
 {g51=exp(gammln(PAL));
  g52=pow(PBE,PAL);
  g53=PSD[mergenum][i]*PSD[mergenum+1][i]/MAUXPSD[mergenum][i];
  g54=pow(g53,PAL-1);
  g55=1/PSD[mergenum][i]+1/PSD[mergenum+1][i]-1/MAUXPSD[mergenum][i];
  g56=exp(PBE*g55);
  psdpr[i]=g51*g54*g56/g52;}
  psdratio=1.0;
  for(i=1;i<=NM;i++)
  psdratio*=psdpr[i];      /*PSD prior rate*/
 
  f41=pow(2,RHO*NZ/2);
  f42=pow(3.1415926,NZ*(NZ-1)/4);
  f43=exp(gammln((RHO+1-1)/2));
  f44=exp(gammln((RHO+1-2)/2));
  f47=f41*f42*f43*f44;
  f47=1/f47;
  f48=pow(1/RH,NZ);
  f49=pow(f48,-RHO/2);
  for(i=1;i<=NZ;i++)
   for(j=1;j<=NZ;j++)
    w[i][j]=PHI[mergenum+1][i][j];
  f53=determinant(w,NZ);
  f54=pow(f53,-(RHO+NZ+1)/2);
  for(i=1;i<=NZ;i++)
  w[i][i]=RH*w[i][i];
  iv(w,NZ+1);
  f55=w[1][1]+w[2][2];
  f56=exp(-0.5*f55);
  phiratio=f47*f49*f54*f56;
  phiratio=1/phiratio;           /*PHI prior ratio*/
  
  for(i=1;i<=NY;i++)
   randompra[i]=normaldistributionpdf(randomvalued[i],0,0.25);
  for(i=1;i<=6;i++)
   randompra[i+9]=normaldistributionpdf(randomvalued[i+9],0,0.25);
  for(i=1;i<=2;i++)
   randompra[i+15]=normaldistributionpdf(randomvalued[i+24],0,0.25);
  for(i=1;i<=3;i++)
   randompra[i+17]=normaldistributionpdf(randomvalued[i+27],0,1);
  
 mujacobian=1/pow(2,NY);
 lyjacobian=1/pow(2,6);
 psxjacobian=pow(2,NY);
 for(i=1;i<=NY;i++)
  psxjacobian*=MAUXPSX[mergenum][i];
 psxjacobian=1/psxjacobian;
 pbjacobian=1/pow(2,2);
 psdjacobian=pow(2,NM);
 for(i=1;i<=NM;i++)
  psdjacobian*=MAUXPSD[mergenum][i];
 psdjacobian=1/psdjacobian;
 phijacobian=pow(2,NZ)*pow(randomvalued[28],2)*randomvalued[30];
 phijacobian=1/fabs(phijacobian);
 
 acceptrate1=1.0;
 for(i=1;i<=20;i++)
 acceptrate1*=randompra[i];
 
 acceptrate=likelyhoodratio*acceptrate1*jumpratio*muratio*lyratio*psxratio*pbratio*psdratio*transprratio;
 acceptrate*=phijacobian*phiratio*mujacobian*lyjacobian*psxjacobian*pbjacobian*psdjacobian;

 
//   dat=fopen("mergeacceptrate.txt","a");
//   fprintf(dat,"The likelyhoodratio is %3.63f\n",likelyhoodratio);
//   fprintf(dat,"The jumpratio is %lf\n",jumpratio);
//   fprintf(dat,"The transprratio is %lf\n",transprratio);
//   fprintf(dat,"The muratio is %3.63f\n",muratio);
//   fprintf(dat,"The lyratio is %3.63f\n",lyratio);
//   fprintf(dat,"The psxratio is %3.63f\n",psxratio);
//   fprintf(dat,"The pbratio is %lf\n",pbratio);
//   fprintf(dat,"The psdratio is %lf\n",psdratio);
//   fprintf(dat,"The phiratio is %3.63f\n",phiratio);
//   fprintf(dat,"The mujacobian is %lf\n",mujacobian);
//   fprintf(dat,"The lyjacobian is %lf\n",lyjacobian);
//   fprintf(dat,"The psxjacobian is %lf\n",psxjacobian);
//   fprintf(dat,"The pbjacobian is %lf\n",pbjacobian);
//   fprintf(dat,"The psdjacobian is %lf\n",pbjacobian);
//   fprintf(dat,"The phijacobian is %lf\n",phijacobian);
//   fprintf(dat,"The acceptrate1 is %3.63f\n",acceptrate1);
//   fprintf(dat,"The acceptrate is %3.63f\n",acceptrate);
//   fprintf(dat,"\n\n\n");
//   fclose(dat);
 
 
 free_vector(va,1,NY);
 free_matrix(mb,1,NY,1,NY);
 free_vector(psxpr,1,NY); 
 free_vector(psdpr,1,NM);
 free_matrix(w,1,NZ,1,NZ);
 free_vector(randompra,1,100);
 free_vector(randomprb,1,100);
 
 return acceptrate;
 }
