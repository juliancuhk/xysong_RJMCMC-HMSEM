jumpto(int currentNC)
{int k;
 long random;
 double u;
  
 if(currentNC==2) k=3;
  else if(currentNC==MAXHIDDENSTATE) k=MAXHIDDENSTATE-1;
   else
   { random=rand();
     u=ran2(&random);
     if(u<0.5) k=currentNC+1;
      else k=currentNC-1; }
   return k;
    }
