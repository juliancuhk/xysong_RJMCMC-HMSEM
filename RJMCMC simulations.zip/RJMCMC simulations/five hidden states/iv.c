void iv(double **W, int Dim)
{
	int  i, j, *indx;
	double  **fma, *col, d;

	fma=matrix(1, Dim, 1, Dim);
	indx=ivector(1, Dim);
	col=vector(1, Dim);      

	for (i=1; i<Dim; i++)
		for (j=1; j<Dim; j++)
			fma[i][j]=W[i][j];

	ludcmp(fma, Dim-1, indx, &d);

	for (i=1; i<Dim; i++) {
		for (j=1; j<Dim; j++)
			col[j]=0;
		
		col[i]=1;
		
		lubksb(fma, Dim-1, indx, col);
		
		for (j=1; j<Dim; j++)
			W[i][j]=col[j];
	}

	free_matrix(fma, 1, Dim, 1, Dim);
	free_ivector(indx, 1, Dim);
	free_vector(col, 1, Dim);

	return ;
}

