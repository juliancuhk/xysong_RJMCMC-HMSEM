double acceptsplitprobability(int currenthiddenstate,int proposalhiddenstate,int splitnum,int **ZID,int **SAUXZID,double ***YO,double **TRANSPR,double **SAUXTRANS,double **MU,double **SAUXMU,double ***LY,double ***SAUXLY,double **PSX,double **SAUXPSX,double ***PB,double ***SAUXPB,double ***PI,double ***SAUXPI,double **PSD,double **SAUXPSD,double ***PHI,double ***SAUXPHI,double ***XI,double *generaterandom,double *proposalrandomvalue,double *hypermu,double **mucov,double *shapeparameter)
{int i,j,k,m,n;
 double a1,a2,b1,b2,c,f1,f2,g11,g12,g13,g14,g15,g16,fly1,fly2,fly3,fly4,fly5,fly6,fly7,fly8,fly9,fly10,fly11,g31,g32,g33,g34,g35,g36,f71,f72,f73,f74,f75,f81,f82,f83,f84,f85,f86;
 double f41,f42,f43,f44,f45,f46,f47,f48,f49,f51,f52,f53,f54,f55,f56,f57,f58,f59,f60;
 double likelyhoodratio,jumpratio,transprratio,muratio,lyratio,psxratio,phiratio,piratio,pbratio,psdratio,mujacobian,lyjacobian,psxjacobian,pijacobian,pbjacobian,psdjacobian,phijacobian,acceptrate1,acceptrate2,acceptrate3,acceptrate4,acceptrate5,acceptrate6,acceptrate7,acceptrate8,acceptrate9,acceptrate,phirate;
 double *va,**mb,*psxpr,*psdpr,**w,*randomnumpr,*randomvalueprobability;
 FILE *dat;
 va=vector(1,NY);
 mb=matrix(1,NY,1,NY);
 psxpr=vector(1,NY);
 psdpr=vector(1,NM);
 w=matrix(1,NZ,1,NZ);
 randomnumpr=vector(1,100);
 randomvalueprobability=vector(1,100);
 
 likelyhoodratio=1.0;
 for(i=1;i<=NO;i++)
  for(j=1;j<=NT;j++)
   {f1=0;
    f2=0;
    
    for(m=1;m<=NY;m++)
    {a1=YO[i][j][m]-MU[ZID[i][j]][m];
     for(n=1;n<=NK;n++) a1-=LY[ZID[i][j]][m][n]*XI[i][j][n];
     f1-=0.5*log(PSX[ZID[i][j]][m])+0.5*a1*a1/PSX[ZID[i][j]][m];}
     b1=exp(f1);
     
    for(m=1;m<=NY;m++)
    {a2=YO[i][j][m]-SAUXMU[SAUXZID[i][j]][m];
     for(n=1;n<=NK;n++) a2-=SAUXLY[SAUXZID[i][j]][m][n]*XI[i][j][n];
     f2-=0.5*log(SAUXPSX[SAUXZID[i][j]][m])+0.5*a2*a2/SAUXPSX[SAUXZID[i][j]][m];}
     b2=exp(f2);
     c=b2/b1;
     likelyhoodratio*=c;}
 
 
  jumpratio=jumprate(proposalhiddenstate,currenthiddenstate)/jumprate(currenthiddenstate,proposalhiddenstate);
  
  transprratio=calculatetransprratio(currenthiddenstate,proposalhiddenstate);
 
  g11=8*pow(3.1415926,3)*sqrt(determinant(mucov,NY));
  g12=1/g11;
  for(i=1;i<=NY;i++)
   for(j=1;j<=NY;j++)
    mb[i][j]=mucov[i][j];
  iv(mb,NY+1);
  for(i=1;i<=NY;i++)
  va[i]=SAUXMU[splitnum][i]-hypermu[i];
  g13=calculatematrix(va,mb);
  for(i=1;i<=NY;i++)
  va[i]=SAUXMU[splitnum+1][i]-hypermu[i];
  g14=calculatematrix(va,mb);
  for(i=1;i<=NY;i++)
  va[i]=MU[splitnum][i]-hypermu[i];
  g15=calculatematrix(va,mb);
  g16=exp(-0.5*(g13+g14-g15));
  muratio=g12*g16;                            /*MU prior rate*/
  
 fly1=normaldistributionpdf(SAUXLY[splitnum][2][1],0,SAUXPSX[splitnum][2])*normaldistributionpdf(SAUXLY[splitnum+1][2][1],0,SAUXPSX[splitnum+1][2])/normaldistributionpdf(LY[splitnum][2][1],0,PSX[splitnum][2]);
 fly2=normaldistributionpdf(SAUXLY[splitnum][3][1],0,SAUXPSX[splitnum][3])*normaldistributionpdf(SAUXLY[splitnum+1][3][1],0,SAUXPSX[splitnum+1][3])/normaldistributionpdf(LY[splitnum][3][1],0,PSX[splitnum][3]);
 fly3=normaldistributionpdf(SAUXLY[splitnum][5][2],0,SAUXPSX[splitnum][5])*normaldistributionpdf(SAUXLY[splitnum+1][5][2],0,SAUXPSX[splitnum+1][5])/normaldistributionpdf(LY[splitnum][5][2],0,PSX[splitnum][5]);
 fly4=normaldistributionpdf(SAUXLY[splitnum][6][2],0,SAUXPSX[splitnum][6])*normaldistributionpdf(SAUXLY[splitnum+1][6][2],0,SAUXPSX[splitnum+1][6])/normaldistributionpdf(LY[splitnum][6][2],0,PSX[splitnum][6]);
 fly5=normaldistributionpdf(SAUXLY[splitnum][8][3],0,SAUXPSX[splitnum][8])*normaldistributionpdf(SAUXLY[splitnum+1][8][3],0,SAUXPSX[splitnum+1][8])/normaldistributionpdf(LY[splitnum][8][3],0,PSX[splitnum][8]);
 fly6=normaldistributionpdf(SAUXLY[splitnum][9][3],0,SAUXPSX[splitnum][9])*normaldistributionpdf(SAUXLY[splitnum+1][9][3],0,SAUXPSX[splitnum+1][9])/normaldistributionpdf(LY[splitnum][9][3],0,PSX[splitnum][9]);
 lyratio=fly1*fly2*fly3*fly4*fly5*fly6;                 /*LY prior rate*/
 
 for(i=1;i<=NY;i++)
 {g31=pow(PBETA,PALPA);
  g32=exp(gammln(PALPA));
  g33=PSX[splitnum][i]/(SAUXPSX[splitnum][i]*SAUXPSX[splitnum+1][i]);
  g34=pow(g33,PALPA-1);
  g35=1/PSX[splitnum][i]-1/SAUXPSX[splitnum][i]-1/SAUXPSX[splitnum+1][i];
  g36=exp(PBETA*g35);
  psxpr[i]=g31*g34*g36/g32;}
  psxratio=1.0;
  for(i=1;i<=NY;i++)
  psxratio*=psxpr[i];      /*PSX prior rate*/
  
  
 f71=normaldistributionpdf(SAUXPB[splitnum][1][1],0,SAUXPSD[splitnum][1])*normaldistributionpdf(SAUXPB[splitnum+1][1][1],0,SAUXPSD[splitnum+1][1])/normaldistributionpdf(PB[splitnum][1][1],0,PSD[splitnum][1]);
 f72=normaldistributionpdf(SAUXPB[splitnum][1][2],0,SAUXPSD[splitnum][1])*normaldistributionpdf(SAUXPB[splitnum+1][1][2],0,SAUXPSD[splitnum+1][1])/normaldistributionpdf(PB[splitnum][1][2],0,PSD[splitnum][1]);
 pbratio=f71*f72;             /*PB prior rate*/ 
  
 for(i=1;i<=NM;i++)
  {f81=pow(PBE,PAL);
   f82=exp(gammln(PAL));
   f83=PSD[splitnum][i]/(SAUXPSD[splitnum][i]*SAUXPSD[splitnum+1][i]);
   f84=pow(f83,PAL-1);
   f85=1/PSD[splitnum][i]-1/SAUXPSD[splitnum][i]-1/SAUXPSD[splitnum+1][i];
   f86=exp(PBE*f85);
   psdpr[i]=f81*f84*f86/f82;}
  psdratio=1;
  for(i=1;i<=NM;i++)
   psdratio*=psdpr[i];      /*PSD prior rate*/ 
  
  f41=pow(2,RHO*NZ/2);
  f42=pow(3.1415926,NZ*(NZ-1)/4);
  f43=exp(gammln((RHO+1-1)/2));
  f44=exp(gammln((RHO+1-2)/2));
  f47=f41*f42*f43*f44;
  f47=1/f47;
  for(i=1;i<=NZ;i++)
   for(j=1;j<=NZ;j++)
    w[i][j]=SAUXPHI[splitnum][i][j];
  f48=determinant(w,NZ);
  f49=pow(f48,-(RHO+NZ+1)/2);
  iv(w,NZ+1);
  f51=w[1][1]+w[2][2];
  f52=exp(-0.5*f51);
  for(i=1;i<=NZ;i++)
   for(j=1;j<=NZ;j++)
    w[i][j]=SAUXPHI[splitnum+1][i][j];
  f53=determinant(w,NZ);
  f54=pow(f53,-(RHO+NZ+1)/2);
  iv(w,NZ+1);
  f55=w[1][1]+w[2][2];
  f56=exp(-0.5*f55);
  for(i=1;i<=NZ;i++)
   for(j=1;j<=NZ;j++)
    w[i][j]=PHI[splitnum][i][j];
  f57=determinant(w,NZ);
  f58=pow(f57,-(RHO+NZ+1)/2);
  iv(w,NZ+1);
  f59=w[1][1]+w[2][2];
  f60=exp(-0.5*f59);
  phiratio=f47*f49*f52*f54*f56/(f58*f60);        /*PHI prior rate*/ 
  
  
  randomnumpr[1]=betadistributionpdf(generaterandom[1],2,2);
  for(i=2;i<2*currenthiddenstate;i++)
  randomnumpr[i]=betadistributionpdf(generaterandom[i],shapeparameter[1],shapeparameter[2]);              
  
  for(i=1;i<=NY;i++) randomvalueprobability[i]=normaldistributionpdf(proposalrandomvalue[i],0,0.25);
  for(i=1;i<=6;i++) randomvalueprobability[9+i]=normaldistributionpdf(proposalrandomvalue[i],0,0.25);
  for(j=1;j<=2;j++) randomvalueprobability[15+j]=normaldistributionpdf(proposalrandomvalue[24+j],0,0.25);
  for(k=1;k<=3;k++) randomvalueprobability[17+k]=normaldistributionpdf(proposalrandomvalue[27+k],0,1);
  
  
  mujacobian=pow(2,NY);
  lyjacobian=pow(2,6);
  psxjacobian=pow(2,NY);
  for(i=1;i<=NY;i++)
   psxjacobian*=PSX[splitnum][i];
  pbjacobian=pow(2,2);
  phijacobian=pow(2,2)*pow(proposalrandomvalue[28],2)*proposalrandomvalue[30];
  phijacobian=fabs(phijacobian);
  psdjacobian=pow(2,NM);
  for(i=1;i<=NM;i++)
  psdjacobian*=PSD[splitnum][i];
  
  acceptrate1=likelyhoodratio;
  for(i=1;i<=20;i++) acceptrate1/=randomvalueprobability[i];
  for(i=1;i<2*currenthiddenstate;i++) acceptrate1/=randomnumpr[i];
  
  
  acceptrate=acceptrate1*jumpratio*transprratio*muratio*mujacobian*lyjacobian*lyratio*psxratio*psxjacobian*pbratio*pbjacobian*psdratio*psdjacobian*phiratio*phijacobian;
  
  
  
//   dat=fopen("splitacceptrate.txt","a");
//   fprintf(dat,"The likelyhoodratio is %3.63f\n",likelyhoodratio);
//   fprintf(dat,"The jumpratio is %lf\n",jumpratio);
//   fprintf(dat,"The transprratio is %lf\n",transprratio);
//   fprintf(dat,"The muratio is %3.63f\n",muratio);
//   fprintf(dat,"The lyratio is %3.63f\n",lyratio);
//   fprintf(dat,"The psxratio is %3.63f\n",psxratio);
//   fprintf(dat,"The pbratio is %lf\n",pbratio);
//   fprintf(dat,"The psdratio is %lf\n",psdratio);
//   fprintf(dat,"The phiratio is %3.63f\n",phiratio);
//   fprintf(dat,"The f47 is %3.63f\n",f47);
//   fprintf(dat,"The f49 is %3.63f\n",f49);
//   fprintf(dat,"The f52 is %3.63f\n",f52);
//   fprintf(dat,"The f54 is %3.63f\n",f54);
//   fprintf(dat,"The f56 is %3.63f\n",f56);
//   fprintf(dat,"The f58 is %3.63f\n",f58);
//   fprintf(dat,"The f60 is %3.63f\n",f60);
//   fprintf(dat,"The mujacobian is %lf\n",mujacobian);
//   fprintf(dat,"The lyjacobian is %lf\n",lyjacobian);
//   fprintf(dat,"The psxjacobian is %lf\n",psxjacobian);
//   fprintf(dat,"The pbjacobian is %lf\n",pbjacobian);
//   fprintf(dat,"The psdjacobian is %lf\n",psdjacobian);
//   fprintf(dat,"The phijacobian is %lf\n",phijacobian);
//   fprintf(dat,"The acceptrate is %3.63f\n",acceptrate);
//   fprintf(dat,"\n\n\n");
//   fclose(dat);
  
 
 free_vector(va,1,NY);
 free_matrix(mb,1,NY,1,NY); 
 free_vector(psxpr,1,NY);
 free_vector(psdpr,1,NM);
 free_matrix(w,1,NZ,1,NZ);
 free_vector(randomnumpr,1,100);
 free_vector(randomvalueprobability,1,100);
 
 return acceptrate;
 }
