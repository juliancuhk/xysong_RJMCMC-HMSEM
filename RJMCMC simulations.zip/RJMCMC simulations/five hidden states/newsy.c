void  newsy(int k, int zc, int **CLM, int *NUM,  double ***ETA, double ***LY, double *NEYO, double ***PLY, double **PSI, int *ROW)
	 {
	    int    i, j, m,n;
	    long   radom;
	    double  AA, AK;
	    double **imaf,**SIMG,*AMU,*COL,*PP,*XX;
	    imaf=matrix(1,NK,1,NK);
	    SIMG=matrix(1,NK,1,NK);
	    AMU=vector(1,NK);
	    COL=vector(1,NK);
	    PP=vector(1,NK);
	    XX=vector(1,NK);


	   for(i=1;i<=NK;i++)
	       for(j=1;j<=NK;j++){
		 SIMG[i][j]=0.0;
		 for(m=1;m<=NUM[zc];m++)
		 SIMG[i][j]+=ETA[zc][m][i]*ETA[zc][m][j];
		  }

	   for(i=1;i<=ROW[k]; i++){
	       /*AMU[i]=PLY[zc][k][i];*/
	       n=CLM[k][i];
	       AMU[i]=PLY[zc][k][n];
	       for(m=1; m<=NUM[zc];m++)
	          AMU[i]+=NEYO[m]*ETA[zc][m][n];
       }
	   for(i=1;i<=ROW[k];i++)
          for(j=1;j<=ROW[k];j++){
		     m=CLM[k][i];
		     n=CLM[k][j];
		     imaf[i][j]=SIMG[m][n];
		     if(i==j) imaf[i][j]+=1.0;    
          }
          
       if(ROW[k]>0){
         choldc(imaf, ROW[k], PP);
         for(m=1;m<=ROW[k];m++){
	        for(i=1;i<=ROW[k];i++)
	           COL[i]=0.0;
	        COL[m]=1.0;
	        cholsl(imaf, ROW[k], PP, COL, XX);
	        for(i=1; i<=ROW[k];i++)  SIMG[i][m]=XX[i];
	     }
       } /*if*/

	   for(m=1;m<=ROW[k];m++)
	     for(j=1;j<=ROW[k];j++)
		    imaf[m][j]=SIMG[m][j];

       choldc(imaf, ROW[k], PP);
	   for(m=1; m<=ROW[k];m++)
	      for(i=m;i<=ROW[k];i++){
	         if(i==m)  imaf[m][i]=PP[m];
	         else   imaf[m][i]=0.0;
	      }

	  AK=PBETA;
	  for(i=1;i<=NUM[zc];i++)
	     AK+=0.5*NEYO[i]*NEYO[i];
      for(i=1;i<=ROW[k];i++){
          n=CLM[k][i];                   
          AK+=0.5*PLY[zc][k][n]*PLY[zc][k][n];
      }
	  for(i=1;i<=ROW[k];i++){
	     XX[i]=0.0;
	     for(j=1;j<=ROW[k];j++)
		    XX[i]+=SIMG[i][j]*AMU[j];
	     AK-=0.5*AMU[i]*XX[i];
	  }

	  m=NUM[zc]/2+PALPA;
      radom=rand();
	  if(NUM[zc]%2==0)
	     PSI[zc][k]=AK/gamdev(m,&radom);
	  else
	    {
	    AA=gasdev(&radom);
	    radom=rand();
	    PSI[zc][k]=AK/(gamdev(m,&radom)+0.5*AA*AA);
	    }

	    for(i=1;i<=ROW[k];i++){
		 radom=rand();
		 PP[i]=gasdev(&radom);
	     }
	    for(i=1;i<=ROW[k];i++)
		for(j=1;j<=ROW[k];j++)
		   XX[i]+=sqrt(PSI[zc][k])*imaf[i][j]*PP[j];

	    for(i=1;i<=ROW[k];i++){
		   m=CLM[k][i];
		   LY[zc][k][m]=XX[i];
	    }

   free_matrix(imaf,1,NK,1,NK);
   free_matrix(SIMG,1,NK,1,NK);
   free_vector(AMU,1,NK);
   free_vector(COL,1,NK);
   free_vector(PP,1,NK);
   free_vector(XX,1,NK);

}/*end of newsy.c */
