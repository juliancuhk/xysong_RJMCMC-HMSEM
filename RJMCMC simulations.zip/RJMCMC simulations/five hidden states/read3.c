void read3(double **TRANSPR, double ***LY, double ***PLY, double **MU, double **PSX)
{int i,j,k;
 FILE *dat;
 
 dat=fopen("int1.dat","r");
  
  for(i=1;i<=INITHIDDENSTATE;i++)
   for(j=1;j<=INITHIDDENSTATE;j++)
    fscanf(dat,"%lf",&TRANSPR[i][j]);
    
  for(k=1;k<=INITHIDDENSTATE;k++)
   for(i=1;i<=NY;i++)
    for(j=1;j<=NK;j++)
     fscanf(dat,"%lf",&LY[k][i][j]);
       
   for(i=1;i<=NY;i++)
    for(j=1;j<=NK;j++)
     fscanf(dat,"%lf",&PLY[1][i][j]);   

   for(k=1;k<=INITHIDDENSTATE;k++)
    for(i=1;i<=NY;i++)
     fscanf(dat,"%lf  %lf",&MU[k][i],&PSX[k][i]);
     
     fclose(dat);
     
   for(k=2;k<=MAXHIDDENSTATE;k++)
    for(i=1;i<=NY;i++)
     for(j=1;j<=NK;j++)
      PLY[k][i][j]=PLY[1][i][j];
     }
