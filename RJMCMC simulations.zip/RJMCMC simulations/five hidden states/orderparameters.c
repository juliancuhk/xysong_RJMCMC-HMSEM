void orderparameters(int currentNC,double **MU,double ***LY,double **PSX,double ***BI,double ***PHI,double **PSD,double **TRANSPR)
{int a,i,j,k;
 a=currentNC;
 
 double **HMU,***HLY,**HPSX,***HBI,***HPHI,**HPSD,**HTRANSPR;
 HLY=f3tensor(1,MAXHIDDENSTATE,1,NY,1,NK);
 HMU=matrix(1,MAXHIDDENSTATE,1,NY);
 HTRANSPR=matrix(1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
 HPSX=matrix(1,MAXHIDDENSTATE,1,NY);
 HBI=f3tensor(1,MAXHIDDENSTATE,1,NM,1,NK);
 HPHI=f3tensor(1,MAXHIDDENSTATE,1,NZ,1,NZ);
 HPSD=matrix(1,MAXHIDDENSTATE,1,NM);
 
 int *order;
 order=ivector(1,a);
 
 for(i=1;i<=a;i++)
  HMU[i][1]=200.0;
 
 for(i=1;i<=a;i++)
  if(MU[i][1]<HMU[1][1]) HMU[1][1]=MU[i][1];
   else HMU[1][1]=HMU[1][1];
   
 for(j=2;j<=a;j++){
  for(i=1;i<=a;i++)
   if(MU[i][1]>HMU[j-1][1]&&MU[i][1]<HMU[j][1]) HMU[j][1]=MU[i][1];
    else HMU[j][1]=HMU[j][1]; }
    
  for(i=1;i<=a;i++){
   for(j=1;j<=a;j++)   
    {if(MU[j][1]==HMU[i][1]) order[i]=j;
    else ;}}
    
  for(i=1;i<=a;i++)
   for(j=1;j<=NY;j++)
    HMU[i][j]=MU[order[i]][j];
    
  for(i=1;i<=a;i++)
   for(j=1;j<=NY;j++)
    MU[i][j]=HMU[i][j];
    
  for(i=1;i<=a;i++)
   for(j=1;j<=NY;j++)
    for(k=1;k<=NK;k++)
     HLY[i][j][k]=LY[order[i]][j][k];
     
  for(i=1;i<=a;i++)
   for(j=1;j<=NY;j++)
    for(k=1;k<=NK;k++)
     LY[i][j][k]=HLY[i][j][k];
     
  for(i=1;i<=a;i++)
   for(j=1;j<=NY;j++)
    HPSX[i][j]=PSX[order[i]][j];
    
  for(i=1;i<=a;i++)
   for(j=1;j<=NY;j++)
    PSX[i][j]=HPSX[i][j];
    
  for(i=1;i<=a;i++)
   for(j=1;j<=a;j++)
   HTRANSPR[i][j]=TRANSPR[order[i]][order[j]];
   
  for(i=1;i<=a;i++)
   for(j=1;j<=a;j++)
    TRANSPR[i][j]=HTRANSPR[i][j];
   
  for(i=1;i<=a;i++)
   for(j=1;j<=NM;j++)
    for(k=1;k<=NK;k++)
     HBI[i][j][k]=BI[order[i]][j][k];
     
  for(i=1;i<=a;i++)
   for(j=1;j<=NM;j++)
    for(k=1;k<=NK;k++)
     BI[i][j][k]=HBI[i][j][k];
     
  for(i=1;i<=a;i++)
   for(j=1;j<=NZ;j++)
    for(k=1;k<=NZ;k++)
     HPHI[i][j][k]=PHI[order[i]][j][k];
     
  for(i=1;i<=a;i++)
   for(j=1;j<=NZ;j++)
    for(k=1;k<=NZ;k++)
     PHI[i][j][k]=HPHI[i][j][k];
     
  for(i=1;i<=a;i++)
   for(j=1;j<=NM;j++)
    HPSD[i][j]=PSD[order[i]][j];
    
  for(i=1;i<=a;i++)
   for(j=1;j<=NM;j++)
    PSD[i][j]=HPSD[i][j];   
 
 free_f3tensor(HLY,1,MAXHIDDENSTATE,1,NY,1,NK);
 free_matrix(HMU,1,MAXHIDDENSTATE,1,NY);
 free_matrix(HPSX,1,MAXHIDDENSTATE,1,NY);
 free_f3tensor(HBI,1,MAXHIDDENSTATE,1,NM,1,NK);
 free_f3tensor(HPHI,1,MAXHIDDENSTATE,1,NZ,1,NZ);
 free_matrix(HPSD,1,MAXHIDDENSTATE,1,NM);
 free_ivector(order,1,a);
 free_matrix(HTRANSPR,1,MAXHIDDENSTATE,1,MAXHIDDENSTATE);
}
