generatehiddenstate(int **ZID, double **TRANSPR)
{int ra,i,s,d,t,j,m,n;
 long random1,random2;
 double unfm, *p, *pr, unif;
 float a;
 
 
 
 ra=REALHIDDENSTATE;
 a=1.0/ra;
 p=vector(1,ra);
 
 for(i=1;i<=ra;i++)
  p[i]=i*a;
  
 for(i=1;i<=NO;i++)
 { random1=rand();
   unfm=ran2(&random1); 
   
   for(s=1;s<=ra&&unfm>p[s];s++)
        ;
        d=s;
        
        ZID[i][1]=d;} 
   
 pr=vector(1,ra);
 
 for(i=1;i<=NO;i++)
  for(t=2;t<=NT;t++)
   {
    for(j=1;j<=REALHIDDENSTATE;j++)
     pr[j]=TRANSPR[ZID[i][t-1]][j];
     
     
     
    for(j=2;j<=REALHIDDENSTATE;j++)
     pr[j]=pr[j]+pr[j-1];
     
   random2=rand();
   unif=ran2(&random2); 
   
   for(m=1;m<=ra&&unif>pr[m];m++)
        ;
        ZID[i][t]=m;
        }  
 
 
 free_vector(p,1,ra);
 free_vector(pr,1,ra);
 
 }
