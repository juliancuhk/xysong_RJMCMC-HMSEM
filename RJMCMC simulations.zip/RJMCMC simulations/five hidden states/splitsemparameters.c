splitsemparameters(int currenthiddenstate,int proposalhiddenstate,int splitnum,double **MU,double **SAUXMU,double ***LY,double ***SAUXLY,double **PSX,double **SAUXPSX,double ***PB,double ***SAUXPB,double ***PI,double ***SAUXPI,double **PSD,double **SAUXPSD,double ***PHI,double ***SAUXPHI,double *proposalrandomvalue)
{int i,j,k;
 long random;
 
 for(i=1;i<=9;i++)
 {random=rand();
  proposalrandomvalue[i]=0.25*gasdev(&random);          /*generate random numbers for MU*/
  }
 
 for(i=10;i<=15;i++)
 {random=rand();
  proposalrandomvalue[i]=0.25*gasdev(&random);          /*generate random numbers for LY*/
  }
 
 for(i=16;i<=24;i++)
 {random=rand();
  proposalrandomvalue[i]=ran2(&random);            /*generate random numbers for PSX*/
  proposalrandomvalue[i]-=0.5;}
  
 for(i=25;i<=26;i++)
 {random=rand();
  proposalrandomvalue[i]=0.25*gasdev(&random);          /*generate random numbers for BI*/
  }
  
 for(i=27;i<=27;i++)
 {random=rand();
  proposalrandomvalue[i]=ran2(&random);             /*generate random numbers for PSD*/
  proposalrandomvalue[i]-=0.5;}
  
 for(i=28;i<=30;i++)
 {random=rand();
  proposalrandomvalue[i]=gasdev(&random);            /*generate random numbers for PHI*/
  } 
  
  
 
 for(i=1;i<splitnum;i++)
  for(j=1;j<=NY;j++)
   SAUXMU[i][j]=MU[i][j];
 
 for(i=1;i<=NY;i++)
  SAUXMU[splitnum][i]=MU[splitnum][i]-proposalrandomvalue[i];
 for(i=1;i<=NY;i++)
  SAUXMU[splitnum+1][i]=MU[splitnum][i]+proposalrandomvalue[i];
  
 for(i=splitnum+2;i<=proposalhiddenstate;i++)
  for(j=1;j<=NY;j++)
   SAUXMU[i][j]=MU[i-1][j];
  /*split MU*/
 
 for(i=1;i<=splitnum;i++)
  for(j=1;j<=NY;j++)
   for(k=1;k<=NK;k++)
    SAUXLY[i][j][k]=LY[i][j][k];
    
  for(j=1;j<=NY;j++)
   for(k=1;k<=NK;k++)
    SAUXLY[splitnum+1][j][k]=LY[splitnum][j][k];
    
   SAUXLY[splitnum][2][1]=LY[splitnum][2][1]-proposalrandomvalue[10];
   SAUXLY[splitnum][3][1]=LY[splitnum][3][1]-proposalrandomvalue[11];
   SAUXLY[splitnum][5][2]=LY[splitnum][5][2]-proposalrandomvalue[12];
   SAUXLY[splitnum][6][2]=LY[splitnum][6][2]-proposalrandomvalue[13];
   SAUXLY[splitnum][8][3]=LY[splitnum][8][3]-proposalrandomvalue[14];
   SAUXLY[splitnum][9][3]=LY[splitnum][9][3]-proposalrandomvalue[15];
   
   SAUXLY[splitnum+1][2][1]=LY[splitnum][2][1]+proposalrandomvalue[10];
   SAUXLY[splitnum+1][3][1]=LY[splitnum][3][1]+proposalrandomvalue[11];
   SAUXLY[splitnum+1][5][2]=LY[splitnum][5][2]+proposalrandomvalue[12];
   SAUXLY[splitnum+1][6][2]=LY[splitnum][6][2]+proposalrandomvalue[13];
   SAUXLY[splitnum+1][8][3]=LY[splitnum][8][3]+proposalrandomvalue[14];
   SAUXLY[splitnum+1][9][3]=LY[splitnum][9][3]+proposalrandomvalue[15];
   
 for(i=splitnum+2;i<=proposalhiddenstate;i++)
  for(j=1;j<=NY;j++)
   for(k=1;k<=NK;k++)
    SAUXLY[i][j][k]=LY[i-1][j][k];
   /*split LY*/
   
 for(i=1;i<splitnum;i++)
  for(j=1;j<=NY;j++)
   SAUXPSX[i][j]=PSX[i][j];
 
 for(i=1;i<=NY;i++)
  SAUXPSX[splitnum][i]=PSX[splitnum][i]*(1-proposalrandomvalue[15+i]);
 for(i=1;i<=NY;i++)
  SAUXPSX[splitnum+1][i]=PSX[splitnum][i]*(1+proposalrandomvalue[15+i]);
 
 for(i=splitnum+2;i<=proposalhiddenstate;i++)
  for(j=1;j<=NY;j++)
   SAUXPSX[i][j]=PSX[i-1][j];
  /*split PSX*/ 
  
 for(i=1;i<=proposalhiddenstate;i++)
  for(j=1;j<=NM;j++)
   for(k=1;k<=NM;k++)
    SAUXPI[i][j][k]=0.0;
    /*given the value of PI*/ 
 
 for(i=1;i<=splitnum;i++)
  for(j=1;j<=NM;j++)
   for(k=1;k<=NZ;k++)
    SAUXPB[i][j][k]=PB[i][j][k];
   
  for(j=1;j<=NM;j++)
   for(k=1;k<=NZ;k++)
    SAUXPB[splitnum+1][j][k]=PB[splitnum][j][k];
    
  SAUXPB[splitnum][1][1]=PB[splitnum][1][1]-proposalrandomvalue[25];
  SAUXPB[splitnum][1][2]=PB[splitnum][1][2]-proposalrandomvalue[26];
  SAUXPB[splitnum+1][1][1]=PB[splitnum][1][1]+proposalrandomvalue[25];
  SAUXPB[splitnum+1][1][2]=PB[splitnum][1][2]+proposalrandomvalue[26];
  
 for(i=splitnum+1;i<=proposalhiddenstate;i++)
  for(j=1;j<=NM;j++)
   for(k=1;k<=NZ;k++)
    SAUXPB[i][j][k]=PB[i-1][j][k];
    /*split PB*/ 
    
    
 for(i=1;i<splitnum;i++)
  for(j=1;j<=NM;j++)
   SAUXPSD[i][j]=PSD[i][j];
   
  SAUXPSD[splitnum][1]=PSD[splitnum][1]*(1-proposalrandomvalue[27]); 
  SAUXPSD[splitnum+1][1]=PSD[splitnum][1]*(1+proposalrandomvalue[27]);
    
 for(i=splitnum+2;i<=proposalhiddenstate;i++)
  for(j=1;j<=NM;j++)
   SAUXPSD[i][j]=PSD[i-1][j];
  /*split PSD*/
  
       
 for(i=1;i<=splitnum;i++)
  for(j=1;j<=NZ;j++)
   for(k=1;k<=NZ;k++)
    SAUXPHI[i][j][k]=PHI[i][j][k];
   
   SAUXPHI[splitnum+1][1][1]=proposalrandomvalue[28]*proposalrandomvalue[28];
   SAUXPHI[splitnum+1][1][2]=proposalrandomvalue[28]*proposalrandomvalue[29];
   SAUXPHI[splitnum+1][2][2]=proposalrandomvalue[29]*proposalrandomvalue[29]+proposalrandomvalue[30]*proposalrandomvalue[30];
   SAUXPHI[splitnum+1][2][1]=SAUXPHI[splitnum+1][1][2];
   
 for(i=splitnum+2;i<=proposalhiddenstate;i++)
  for(j=1;j<=NZ;j++)
   for(k=1;k<=NZ;k++)
    SAUXPHI[i][j][k]=PHI[i-1][j][k];
    /*split PHI*/ 
  
 }
