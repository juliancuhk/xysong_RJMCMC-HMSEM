double calculatetransprratio(int currenthiddenstate,int proposalhiddenstate)
{double a,b,c,d,f,g,h,k,m,n;
 a=exp(gammln(1));
 b=pow(a,currenthiddenstate);
 c=exp(gammln(currenthiddenstate));
 d=c/b;
 f=pow(d,currenthiddenstate);
 g=pow(a,proposalhiddenstate);
 h=exp(gammln(proposalhiddenstate));
 k=h/g;
 m=pow(k,proposalhiddenstate);
 n=m/f;
 return n;}




