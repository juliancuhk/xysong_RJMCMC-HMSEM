double ****array4(int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nel, int neh)
{	
	int i, j, k;
	double ****m;

	m=(double ****) malloc((unsigned) (nrh-nrl+1)*sizeof(double***));
	
	if (!m) 
		nrerror("allocation failure 1 in array4()");

	m-=nrl;

	for (i=nrl; i<=nrh; i++) {
		m[i]=(double ***) malloc((unsigned) (nch-ncl+1)*sizeof(double**));
		
		if (!m[i]) 
			nrerror("allocation failure 2 in array4()");
	
		m[i]-=ncl;

		for (j=ncl; j<=nch; j++) {
			m[i][j]=(double **) malloc((unsigned) (ndh-ndl+1)*sizeof(double*));
	
			if (!m[i][j]) 
				nrerror("allocation failure 3 in array4()");
	
			m[i][j]-=ndl;

			for (k=ndl; k<=ndh; k++) {
				m[i][j][k]=(double *) malloc((unsigned) (neh-nel+1)*sizeof(double));
	
				if (!m[i][j][k])
					nrerror("allocation failure 4 in array4()");
			
				m[i][j][k]-=nel;
			} 
		}
	}

	return m;
}

void free_array4(double ****m, int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nel, int neh)
{
	int i, j, k;
	
	for (i=nrh; i>=nrl; i--) {
		for (j=nch; j>=ncl; j--) {
			for (k=ndh; k>=ndl; k--)
				free((char*) (m[i][j][k]+nel));
			free((char*) (m[i][j]+ndl));
		}
		free((char*) (m[i]+ncl));
	}
	
	free((char*) (m+nrl));

	return ;
}

double *****array5(int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nel, int neh, int nfl, int nfh)
{
	int i, j, k, l;
	double *****m;

	m=(double *****) malloc((unsigned) (nrh-nrl+1)*sizeof(double****));
	if (!m) 
		nrerror("allocation failure 1 in array5()");

	m-=nrl;

	for (i=nrl; i<=nrh; i++) {
		m[i]=(double ****) malloc((unsigned) (nch-ncl+1)*sizeof(double***));
	
		if (!m[i]) 
			nrerror("allocation failure 2 in array5()");
	
		m[i]-=ncl;

		for (j=ncl; j<=nch; j++) {
			m[i][j]=(double ***) malloc((unsigned) (ndh-ndl+1)*sizeof(double**));
	
			if (!m[i][j])
				nrerror("allocation failure 3 in array5()");
	
			m[i][j]-=ndl;

			for (k=ndl; k<=ndh; k++) {
				m[i][j][k]=(double **) malloc((unsigned) (neh-nel+1)*sizeof(double*));
	
				if (!m[i][j][k])
					nrerror("allocation failure 4 in array5()");
	
				m[i][j][k]-=nel;
				
				for (l=nel; l<=neh; l++) {
					m[i][j][k][l]=(double *) malloc((unsigned) (nfh-nfl+1)*sizeof(double));
				
					if(!m[i][j][k][l])
						nrerror("allocation failure 5 in array5()");
				
					m[i][j][k][l]-=nfl;
				} 
			}
		}
	}

	return m;
}

void free_array5(double *****m, int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nel, int neh,
int nfl, int nfh)
{
	int i, j, k, l;
	
	for (i=nrh; i>=nrl; i--) {
		for (j=nch; j>=ncl; j--) {
			for (k=ndh; k>=ndl; k--) {
				for (l=neh; l>=nel; l--)
					free((char*) (m[i][j][k][l]+nfl));
				
				free((char*) (m[i][j][k]+nel));
			}
			free((char*) (m[i][j]+ndl));
		}
		free((char*) (m[i]+ncl));
	}
	
	free((char*) (m+nrl));

	return ;
}


double ******array6(int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nel, int neh, int nfl, int nfh,
int ngl, int ngh)
{
	int i, j, k, l, m;
	double ******t;

	t=(double ******) malloc((unsigned) (nrh-nrl+1)*sizeof(double*****));
	if (!t) 
		nrerror("allocation failure 1 in array6()");

	t-=nrl;

	for (i=nrl; i<=nrh; i++) {
		t[i]=(double *****) malloc((unsigned) (nch-ncl+1)*sizeof(double****));
	
		if (!t[i]) 
			nrerror("allocation failure 2 in array6()");
	
		t[i]-=ncl;

		for (j=ncl; j<=nch; j++) {
			t[i][j]=(double ****) malloc((unsigned) (ndh-ndl+1)*sizeof(double***));
	
			if (!t[i][j])
				nrerror("allocation failure 3 in array6()");
	
			t[i][j]-=ndl;

			for (k=ndl; k<=ndh; k++) {
				t[i][j][k]=(double ***) malloc((unsigned) (neh-nel+1)*sizeof(double**));
	
				if (!t[i][j][k])
					nrerror("allocation failure 4 in array6()");
	
				t[i][j][k]-=nel;
				
				for (l=nel; l<=neh; l++) {
					t[i][j][k][l]=(double **) malloc((unsigned) (nfh-nfl+1)*sizeof(double*));
				
					if (!t[i][j][k][l])
						nrerror("allocation failure 5 in array6()");
				
					t[i][j][k][l]-=nfl;
					
					for (m=nfl; m<=nfh; m++) {
						t[i][j][k][l][m]=(double *) malloc((unsigned) (ngh-ngl+1)*sizeof(double));
					
						if (!t[i][j][k][l][m])
							nrerror("allocation failure 6 in array6()");
						
						t[i][j][k][l][m]-=ngl;						
					}
				} 
			}
		}
	}

	return t;
}

void free_array6(double ******t, int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nel, int neh,
int nfl, int nfh, int ngl, int ngh)
{
	int i, j, k, l, m;
	
	for (i=nrh; i>=nrl; i--) {
		for (j=nch; j>=ncl; j--) {
			for (k=ndh; k>=ndl; k--) {
				for (l=neh; l>=nel; l--) {
					for (m=nfh; m>=nfl; m--)
						free((char*) (t[i][j][k][l][m]+ngl));
					
					free((char*) (t[i][j][k][l]+nfl));
				}
				
				free((char*) (t[i][j][k]+nel));
			}
			free((char*) (t[i][j]+ndl));
		}
		free((char*) (t[i]+ncl));
	}
	
	free((char*) (t+nrl));
	
	// for (i=nrh; i>=nrl; i--)
		// free_array5(t[i], ncl, nch, ndl, ndh, nel, neh, nfl, nfh, ngl, ngh);
	
	// free((char*) (t+nrl));

	return ;
}

int ***if3tensor(long nrl, long nrh, long ncl, long nch, long ndl, long ndh)
/* allocate a int f3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh] */
{
	long i, j, nrow=nrh-nrl+1, ncol=nch-ncl+1, ndep=ndh-ndl+1;
	int ***t;

	/* allocate pointers to pointers to rows */
	t=(int ***) malloc((size_t)((nrow+NR_END)*sizeof(int**)));
	if (!t) 
		nrerror("allocation failure 1 in if3tensor()");
	
	t += NR_END;
	t -= nrl;

	/* allocate pointers to rows and set pointers to them */
	t[nrl]=(int **) malloc((size_t)((nrow*ncol+NR_END)*sizeof(int*)));
	
	if (!t[nrl])
		nrerror("allocation failure 2 in if3tensor()");
	
	t[nrl] += NR_END;
	t[nrl] -= ncl;

	/* allocate rows and set pointers to them */
	t[nrl][ncl]=(int *) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(int)));
	if (!t[nrl][ncl])
		nrerror("allocation failure 3 in if3tensor()");
	
	t[nrl][ncl] += NR_END;
	t[nrl][ncl] -= ndl;

	for (j=ncl+1; j<=nch; j++)
		t[nrl][j]=t[nrl][j-1]+ndep;
	
	for (i=nrl+1; i<=nrh; i++) {
		t[i]=t[i-1]+ncol;
		t[i][ncl]=t[i-1][ncl]+ncol*ndep;
		for(j=ncl+1; j<=nch; j++)
			t[i][j]=t[i][j-1]+ndep;
	}

	/* return pointer to array of pointers to rows */
	return t;
}

void free_if3tensor(int ***t, long nrl, long nrh, long ncl, long nch,long ndl, long ndh)
/* free a int f3tensor allocated by if3tensor() */
{
	free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
	free((FREE_ARG) (t[nrl]+ncl-NR_END));
	free((FREE_ARG) (t+nrl-NR_END));
}
