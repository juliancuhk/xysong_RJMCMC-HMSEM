gey(int **ZID, double ***LY, double **MU, double **PSX, double ***TUE, double ***YO)
{int i,j,k,s;
 double delta;
 long random;
 
 for(i=1;i<=NO;i++)
  for(j=1;j<=NT;j++)
   {
    for(k=1;k<=NY;k++)
    {YO[i][j][k]=0.0;
     random=rand();
     delta=gasdev(&random)*sqrt(PSX[ZID[i][j]][k])+MU[ZID[i][j]][k];
      for(s=1;s<=NK;s++)
       YO[i][j][k]+=LY[ZID[i][j]][k][s]*TUE[i][j][s];
       
       YO[i][j][k]+=delta;
     }
 
 
   }
 
}
