diagnose(int proposalhiddenstate,double **SAUXMU,double **SAUXTRANS)
{int j,a,b,c;
 
 a=1;
  
 for(j=1;j<proposalhiddenstate;j++)
  {if(SAUXMU[j][1]<SAUXMU[j+1][1]) b=1;
    else b=0;
    a*=b;}
   
   
  if(SAUXTRANS[1][1]>1) c=0;
   else c=1;
   
   a*=c;
  
  return a;
  }
