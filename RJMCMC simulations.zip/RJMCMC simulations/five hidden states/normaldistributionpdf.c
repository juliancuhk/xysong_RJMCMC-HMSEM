double normaldistributionpdf(double x,double u,double sigma)
{
 double a,b,c,d;
 a=1/sqrt(2*3.1415926);
 b=1/sqrt(sigma);
 c=-0.5*(x-u)*(x-u)/sigma;
 d=a*b*exp(c);
 
 return d;
       }
