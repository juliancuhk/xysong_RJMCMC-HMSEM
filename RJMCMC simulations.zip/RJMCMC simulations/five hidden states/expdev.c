double expdev(long *idum)
{
	double dum;

	do
		dum=ran2(idum);
	while (dum == 0.0);
	
	return -log(dum);
}
/* (C) Copr. 1986-92 Numerical Recipes Software p,{2. */
