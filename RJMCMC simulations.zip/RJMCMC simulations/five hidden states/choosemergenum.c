#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int choosemergenum(int k)
{ int ra;
 long random;
 double unfm,*pra; 
 float a;
 ra=k-1;
 a=1.0/ra;
 pra=vector(1,ra);
 int i;
 int s,d;
 for(i=1;i<=ra;i++)
  pra[i]=i*a;
  random=rand();
  unfm=ran2(&random);
 for(s=1;s<=ra&&unfm>pra[s];s++)
    ;
    d=s;
    return d;
    
 free_vector(pra,1,ra);
      }
