mergesemparameters(int currenthiddenstate,int proposalhiddenstate,int mergenum,double **MU,double **MAUXMU,double ***LY,double ***MAUXLY,double **PSX,double **MAUXPSX,double ***PB,double ***MAUXPB,double ***PI,double ***MAUXPI,double **PSD,double **MAUXPSD,double ***PHI,double ***MAUXPHI,double *proposaledvalue)
{int i,j,k;
 
 double **w,*p;
 w=matrix(1,NZ,1,NZ);
 p=vector(1,NZ);
 
 for(i=1;i<mergenum;i++)
  for(j=1;j<=NY;j++)
   MAUXMU[i][j]=MU[i][j];
   
 for(i=1;i<=NY;i++)
  MAUXMU[mergenum][i]=(MU[mergenum][i]+MU[mergenum+1][i])/2;
  
 for(i=mergenum+1;i<=proposalhiddenstate;i++)
  for(j=1;j<=NY;j++)
   MAUXMU[i][j]=MU[i+1][j];              /*merge MU*/ 
    
 for(i=1;i<=mergenum;i++)
  for(j=1;j<=NY;j++)
   for(k=1;k<=NK;k++)
    MAUXLY[i][j][k]=LY[i][j][k];

 
  MAUXLY[mergenum][2][1]=(LY[mergenum][2][1]+LY[mergenum+1][2][1])/2;
  MAUXLY[mergenum][3][1]=(LY[mergenum][3][1]+LY[mergenum+1][3][1])/2;
  MAUXLY[mergenum][5][2]=(LY[mergenum][5][2]+LY[mergenum+1][5][2])/2;
  MAUXLY[mergenum][6][2]=(LY[mergenum][6][2]+LY[mergenum+1][6][2])/2;
  MAUXLY[mergenum][8][3]=(LY[mergenum][8][3]+LY[mergenum+1][8][3])/2;
  MAUXLY[mergenum][9][3]=(LY[mergenum][9][3]+LY[mergenum+1][9][3])/2;
  
 for(i=mergenum+1;i<=proposalhiddenstate;i++)
  for(j=1;j<=NY;j++)
   for(k=1;k<=NK;k++)
    MAUXLY[i][j][k]=LY[i+1][j][k];                     /*merge LY*/
    
 
 for(i=1;i<=mergenum;i++)
  for(j=1;j<=NZ;j++)
   for(k=1;k<=NZ;k++)
    MAUXPHI[i][j][k]=PHI[i][j][k];
  
 for(i=mergenum+1;i<=proposalhiddenstate;i++)
  for(j=1;j<=NZ;j++)
   for(k=1;k<=NZ;k++)
    MAUXPHI[i][j][k]=PHI[i+1][j][k];                      /*merge PHI*/
 
 
 for(i=1;i<mergenum;i++)
  for(j=1;j<=NM;j++)
   MAUXPSD[i][j]=PSD[i][j];
 
 for(i=1;i<=NM;i++)
  MAUXPSD[mergenum][i]=(PSD[mergenum][i]+PSD[mergenum+1][i])/2;
  
 for(i=mergenum+1;i<=proposalhiddenstate;i++)
  for(j=1;j<=NM;j++)
   MAUXPSD[i][j]=PSD[i+1][j];                                  /*merge PSD*/
   
 
 for(i=1;i<mergenum;i++)
  for(j=1;j<=NY;j++)
   MAUXPSX[i][j]=PSX[i][j];  
 
 for(i=1;i<=NY;i++)
  MAUXPSX[mergenum][i]=(PSX[mergenum][i]+PSX[mergenum+1][i])/2;
  
 for(i=mergenum+1;i<=proposalhiddenstate;i++)
  for(j=1;j<=NY;j++)
   MAUXPSX[i][j]=PSX[i+1][j];                                 /*merge PSX*/
   
    
 for(i=1;i<=mergenum;i++)
  for(j=1;j<=NM;j++)
   for(k=1;k<=NZ;k++)
    MAUXPB[i][j][k]=PB[i][j][k];
    
  MAUXPB[mergenum][1][1]=(PB[mergenum][1][1]+PB[mergenum+1][1][1])/2;
  MAUXPB[mergenum][1][2]=(PB[mergenum][1][2]+PB[mergenum+1][1][2])/2;
  
 for(i=mergenum+1;i<=proposalhiddenstate;i++)
  for(j=1;j<=NM;j++)
   for(k=1;k<=NZ;k++)
    MAUXPB[i][j][k]=PB[i+1][j][k];                               /*merge PB*/
 
    
 for(i=1;i<=NY;i++)
 proposaledvalue[i]=(MU[mergenum+1][i]-MU[mergenum][i])/2;
 
 proposaledvalue[10]=(LY[mergenum+1][2][1]-LY[mergenum][2][1])/2;
 proposaledvalue[11]=(LY[mergenum+1][3][1]-LY[mergenum][3][1])/2; 
 proposaledvalue[12]=(LY[mergenum+1][5][2]-LY[mergenum][5][2])/2; 
 proposaledvalue[13]=(LY[mergenum+1][6][2]-LY[mergenum][6][2])/2; 
 proposaledvalue[14]=(LY[mergenum+1][8][3]-LY[mergenum][8][3])/2; 
 proposaledvalue[15]=(LY[mergenum+1][9][3]-LY[mergenum][9][3])/2; 
 
 for(i=1;i<=NY;i++)
  proposaledvalue[15+i]=(PSX[mergenum+1][i]-PSX[mergenum][i])/(PSX[mergenum][i]+PSX[mergenum+1][i]);
  
 proposaledvalue[25]=(PB[mergenum+1][1][1]-PB[mergenum][1][1])/2;
 proposaledvalue[26]=(PB[mergenum+1][1][2]-PB[mergenum][1][2])/2;
 
 for(i=1;i<=NM;i++)
  proposaledvalue[26+i]=(PSD[mergenum+1][i]-PSD[mergenum][i])/(PSD[mergenum][i]+PSD[mergenum+1][i]);   
  
 for(i=1;i<=NZ;i++)
  for(j=1;j<=NZ;j++)
   w[i][j]=PHI[mergenum+1][i][j];
   
   choldc(w,NZ,p);
  proposaledvalue[28]=p[1];
  proposaledvalue[29]=w[2][1];
  proposaledvalue[30]=p[2]; 
 
    
 free_matrix(w,1,NZ,1,NZ);
 free_vector(p,1,NZ);    
    }
