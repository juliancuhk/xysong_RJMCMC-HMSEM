double betadistributionpdf(double x,double a,double b)
{double f1,f2,f3,f4,f5,f6,z;
 
 f1=exp(gammln(a+b));
 f2=exp(gammln(a));
 f3=exp(gammln(b));
 f4=f2*f3;
 f5=pow(x,a-1);
 f6=pow(1-x,b-1);
 
 z=f1*f5*f6/(f4*1.0);
 
 return z;
 
  }
