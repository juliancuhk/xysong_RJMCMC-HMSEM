splitzid(int currenthiddenstate,int proposalhiddenstate,int splitnum,int **ZID,int **SAUXZID,double ***YO,double **SAUXMU,double ***SAUXLY,double **SAUXPSX,double ***XI)
{int i,j,k,m,n;
 double f1,f2,temp,a,b,c,d;
 long random;
 
 for(i=1;i<=NO;i++)
  for(j=1;j<=NT;j++)
   {if(ZID[i][j]<splitnum) SAUXZID[i][j]=ZID[i][j];
    else if(ZID[i][j]>splitnum) SAUXZID[i][j]=ZID[i][j]+1;
    else
    {f1=0;
     f2=0;
     
     for(m=1;m<=NY;m++) 
     {temp=YO[i][j][m]-SAUXMU[splitnum][m];
     for(n=1;n<=NK;n++) temp-=SAUXLY[splitnum][m][n]*XI[i][j][n];
      f1-=0.5*log(SAUXPSX[splitnum][m])+0.5*temp*temp/SAUXPSX[splitnum][m];}
      a=exp(f1);
      
     for(m=1;m<=NY;m++) 
     {temp=YO[i][j][m]-SAUXMU[splitnum+1][m];
     for(n=1;n<=NK;n++) temp-=SAUXLY[splitnum+1][m][n]*XI[i][j][n];
      f2-=0.5*log(SAUXPSX[splitnum+1][m])+0.5*temp*temp/SAUXPSX[splitnum+1][m];}
      b=exp(f2); 
      
      c=a/(a+b);
      
      random=rand();
      d=ran2(&random);
      
      if(d<c) SAUXZID[i][j]=splitnum;
       else SAUXZID[i][j]=splitnum+1;
       
      
     }
     
    }
   
 }
