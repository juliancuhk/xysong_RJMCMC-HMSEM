readtrueparameters(double ***LY,double **MU,double **PSX,double ***PB,double ***PHI,double ***PI,double **PSD)
{int i,j,k;
 FILE *dat1;
 
 dat1=fopen("trueparameters.dat","r");
 
 for(k=1; k<=REALHIDDENSTATE; k++)
         for(i=1; i<=NY; i++)
            for(j=1; j<=NK; j++)
	           fscanf(dat1,"%lf", &LY[k][i][j]);

      for(i=1;i<=NY;i++)
	     for(k=1; k<=REALHIDDENSTATE; k++)
	        fscanf(dat1, "%lf", &MU[k][i]);

      for(k=1; k<=REALHIDDENSTATE; k++)
        for(i=1; i<=NM; i++)
	       for(j=1; j<=NZ; j++)
	          fscanf(dat1, "%lf", &PB[k][i][j]);
      /* the Gamma matrix in s.e.*/

      for(k=1; k<=REALHIDDENSTATE; k++)
         for(i=1;i<=NZ;i++)
	        for(j=1;j<=NZ;j++)
	           fscanf(dat1,"%lf", &PHI[k][i][j]);

      for(k=1; k<=REALHIDDENSTATE; k++)
         for(i=1;i<=NM;i++)
	         for(j=1;j<=NM;j++)
                fscanf(dat1,"%lf", &PI[k][i][j]);
      /* the PI matirx in s.e.*/

      for(k=1; k<=REALHIDDENSTATE; k++)
         for(i=1;i<=NM;i++)
	        fscanf(dat1,"%lf", &PSD[k][i]);

      for(k=1; k<=REALHIDDENSTATE; k++)
         for(i=1;i<=NY;i++)
	        fscanf(dat1,"%lf", &PSX[k][i]);
      
      fclose(dat1);
 
 }
