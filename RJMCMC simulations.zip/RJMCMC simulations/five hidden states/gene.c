#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>

#include "init.c"
#include "gey.c"

void gene(double ***LY,double **MU,double **PSX,double ***PB,double ***PHI,double ***PI,double **PSD, double ***YO, double ***TUE, int **ZID)
{
 int i,j,k;    
   
   
     
  init(ZID,PB,PI,PHI,PSD,TUE);
  
  gey(ZID,LY,MU,PSX,TUE,YO);
  
  
  }
