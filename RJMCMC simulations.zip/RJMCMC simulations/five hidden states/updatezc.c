updatezc(int currentNC,double *MID,double **MU,double **TRANSPR,double ***SIGMA)
{
  long random;
  int i,j,k,m,zc,t,g;
  double u,uf,T;
  double *b,*fa,**SIG,*de,*U,*pa,*PROP;
  fa=vector(1,currentNC);
  SIG=matrix(1,NY,1,NY);
  de=vector(1,currentNC);
  U=vector(1,NY);
  pa=vector(1,currentNC);
  PROP=vector(1,currentNC);
  b=vector(1,currentNC);
  
   PROP[1]=1.0;
  for(i=2;i<=currentNC;i++)
   PROP[i]=0.0;
   
 for(g=1;g<=1000;g++){
  for(j=1;j<=currentNC;j++)
   {b[j]=0.0;
   for(i=1;i<=currentNC;i++)
    b[j]+=PROP[i]*TRANSPR[i][j];}
  for(t=1;t<=currentNC;t++)
   PROP[t]=b[t];
  }
  
  for(i=1;i<=NY;i++)
   U[i]=MID[i];
   
   for(i=1;i<=currentNC;i++)
    {for(j=1;j<=NY;j++)
      for(k=1;k<=NY;k++)
       SIG[j][k]=SIGMA[i][j][k];
        de[i]=detem(SIG);}
        
   for(i=1;i<=currentNC;i++)
    {fa[i]=0.0;
     for(k=1;k<=NY;k++)
      for(m=1;m<=NY;m++)
       fa[i]+=(U[k]-MU[i][k])*SIGMA[i][k][m]*(U[m]-MU[i][m]);}
        
   T=fa[1];
   for(k=2;k<=currentNC;k++)
    if(fa[k]<T) T=fa[k];
    
   uf=0.0;
   for(k=1;k<=currentNC;k++)
    uf+=de[k]*PROP[k]*exp(-0.5*(fa[k]-T));
   for(i=1;i<=currentNC;i++)
    pa[i]=de[i]*PROP[i]*exp(-0.5*(fa[i]-T))/uf;
    
   T=0.0;
   for(i=1;i<=currentNC;i++)
    {T+=pa[i];
    pa[i]=T;}             
        
  random=rand();
  u=ran2(&random);
  if(u<pa[1]) zc=1;
   else
   {for(j=2;j<=currentNC;j++)
     if(u>pa[j-1]&&u<pa[j]) zc=j;}
  
   
   
   
   free_vector(fa,1,currentNC);
   free_matrix(SIG,1,NY,1,NY);
   free_vector(de,1,currentNC);
   free_vector(U,1,NY);
   free_vector(pa,1,currentNC);
   free_vector(PROP,1,currentNC);
   free_vector(b,1,currentNC);
   
   return zc; 
  
             }
