double calculatematrix(double *a,double **b)
{
 int i;
 double d;
 double *c;
 c=vector(1,NY);
 
 for(i=1;i<=NY;i++)
  c[i]=a[1]*b[1][i]+a[2]*b[2][i]+a[3]*b[3][i]+a[4]*b[4][i]+a[5]*b[5][i]+a[6]*b[6][i];
  
 d=c[1]*a[1]+c[2]*a[2]+c[3]*a[3]+c[4]*a[4]+c[5]*a[5]+c[6]*a[6];
 
 free_vector(c,1,NY);
 
 return d;
       }
