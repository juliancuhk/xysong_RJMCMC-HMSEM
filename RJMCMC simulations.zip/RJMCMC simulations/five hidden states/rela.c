void rela(int currentNC, int *NUM, double ***NXI, double ***NX1, double ***NX2)
   {
       int i, j, k;

    for(k=1; k<=currentNC; k++){ 
       for(j=1; j<=NUM[k]; j++){
          for(i=1; i<=NM; i++)
	         NX1[k][j][i]=NXI[k][j][i];
          for(i=1; i<=NZ; i++)
	         NX2[k][j][i]=NXI[k][j][i+NM];
      }
    }

}/* end */
