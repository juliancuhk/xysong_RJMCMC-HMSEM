double detem(double **SIG1)
 {
      int    i, j, k;
      double  ff;
      double  **fmax,*PP;
      
      fmax=matrix(1,NY,1,NY); 
      PP=vector(1,NY);
       

       for(i=1;i<=NY;i++)
	    for(j=1;j<=NY;j++)
	     fmax[i][j]=SIG1[i][j];


      choldc(fmax, NY, PP);
      ff=1.0;
      for(i=1;i<=NY;i++)
	   ff=ff*PP[i];

      

    free_matrix(fmax,1,NY,1,NY);
    free_vector(PP,1,NY);
     
     return ff;
 }/* end of determinant.c */

