newph(int zc, int *NUM, double ***PHI, double ***ZETA)
   {
      int i, j, k,m;
      long radom;
      double XX;
      double **mxz,*PP,*COL,*YY,**TT,**Wsat;
      mxz=matrix(1,NZ,1,NZ);
      PP=vector(1,NZ);
      COL=vector(1,NZ);
      YY=vector(1,NZ);
      TT=matrix(1,NZ,1,NZ);
      Wsat=matrix(1,NZ,1,NZ);

      
      
      for(i=1; i<=NZ; i++)
         for(j=1; j<=NZ; j++){
            mxz[i][j]=0.0;
            if(i==j) mxz[i][j]=1.0;
            mxz[i][j]=(RH-3.0)*mxz[i][j];
         } 

  
      for(i=1;i<=NZ;i++)
	    for(j=1;j<=NZ;j++){
	       if(i==j){
		      k=(NUM[zc]+RHO-i)/2;
              radom=rand(); 
	          if((NUM[zc]+RHO-i)%2==0){TT[i][i]=sqrt(2.0*gamdev(k, &radom));}
              else{
		         XX=gasdev(&radom);
                 radom=rand();
		         TT[i][i]=sqrt(2.0*gamdev(k, &radom)+XX*XX); }
           }
           else if(i<j) TT[i][j]=0.0;
           else{  radom=rand();
	              TT[i][j]=gasdev(&radom); }
        }

       for(i=1;i<=NZ;i++)    
	      for(j=1;j<=NZ;j++){
	         Wsat[i][j]=0.0;
	         for(k=1;k<=NZ;k++)
	             Wsat[i][j]+=TT[i][k]*TT[j][k];
		  }
       /*  standard Wishart distribution W(I, NUM[zc]+PHO)*/

	   for(k=1;k<=NZ;k++)
	      for(i=1; i<=NZ; i++){
	         for(j=1;j<=NUM[zc];j++)
		        mxz[k][i]+=ZETA[zc][j][k]*ZETA[zc][j][i];  
	      }
       /* mxz=(RH-3.0)I+Z*Z^t */

       choldc(mxz,NZ,PP);             
       for(k=1;k<=NZ;k++){
	      for(i=1;i<=NZ;i++)  COL[i]=0.0;
		  COL[k]=1.0;
          cholsl(mxz,NZ,PP,COL,YY);
	      for(i=1;i<=NZ;i++)  PHI[zc][i][k]=YY[i];
	   }
       /* PHI=inv(mxz)=inv((RH-3.0)I+Z*Z^t) */

       for(k=1;k<=NZ;k++)
	      for(i=1;i<=NZ;i++){
		     mxz[k][i]=PHI[zc][k][i];
		     PHI[zc][k][i]=0.0;  }

	   choldc(mxz,NZ,PP);     /* Choldc decompostion */
	   for(k=1; k<=NZ;k++)
	      for(i=k;i<=NZ;i++){
	        if(i==k) mxz[k][i]=PP[k];
	        else mxz[k][i]=0.0; 
          }

	   for(k=1;k<=NZ;k++)
	      for(i=1;i<=NZ;i++){
	         for(j=1;j<=NZ;j++)
		        for(m=1;m<=NZ;m++)
		           PHI[zc][k][i]+=mxz[k][j]*Wsat[j][m]*mxz[i][m];
          }
       /* Wishart distribution W(inv((RH-3.0)I+Z*Z^t), NUM[zc]+PHO) */

	   for(k=1;k<=NZ;k++)
	      for(i=1;i<=NZ;i++)
		     mxz[k][i]=PHI[zc][k][i];

	   choldc(mxz,NZ,PP);
       for(k=1;k<=NZ;k++){
	      for(i=1;i<=NZ;i++)  COL[i]=0.0;
		  COL[k]=1.0;
          cholsl(mxz,NZ,PP,COL,YY);
	      for(i=1;i<=NZ;i++)  PHI[zc][i][k]=YY[i];
	   }
        /* Inverse-Wishart distribution IW((RH-3.0)I+Z*Z^t, NUM[zc]+PHO) */
        /* if A~W(SIG,m), then B=inv(A)~IW(inv(SIG),m)*/

    free_matrix(mxz,1,NZ,1,NZ);
    free_vector(PP,1,NZ);   
    free_vector(COL,1,NZ);
    free_vector(YY,1,NZ);
    free_matrix(TT,1,NZ,1,NZ);
    free_matrix(Wsat,1,NZ,1,NZ);

}    /* The End  of newphi.c */
