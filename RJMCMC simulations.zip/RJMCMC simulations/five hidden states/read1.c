void  read1(int **CLB, int **CLY, int **IDB, int **IDY, int *ROB, int *ROY)
  {     
     FILE *dat;
     int i, j, k;
     
     dat=fopen("ind.dat", "r");

     for(i=1; i<=NY;i++)
        for(j=1; j<=NK; j++)
           fscanf(dat,"%d", &IDY[i][j]);
     for(i=1; i<=NM;i++)
        for(j=1; j<=NK; j++)
           fscanf(dat,"%d", &IDB[i][j]);
     fclose(dat);

     for(i=1; i<=NY;i++){
        k=1;  ROY[i]=0;
        for(j=1; j<=NK; j++){
            ROY[i]+=IDY[i][j];
            CLY[i][j]=0;
            if(IDY[i][j]==1){
              CLY[i][k]=j;
              k+=1;
            }   }   }
     for(i=1; i<=NM;i++){
        k=1;  ROB[i]=0;
        for(j=1; j<=NK; j++){
            ROB[i]+=IDB[i][j];
            CLB[i][j]=0;
            if(IDB[i][j]==1){
              CLB[i][k]=j;
              k+=1;
            }    }    }
            
        

    }/* end */
