mergeprobabilitymatrix(int currenthiddenstate,int proposalhiddenstate,int mergenum,double **TRANSPR,double **MAUXTRANS,double *mergerandom)
{int m,n;
 double *PROP,sumpr;
 PROP=vector(1,MAXHIDDENSTATE);
 
 stationaryvector(currenthiddenstate,TRANSPR,PROP);
 
      for(m=1;m<mergenum;m++)
      {for(n=1;n<mergenum;n++) MAUXTRANS[m][n]=TRANSPR[m][n];
       MAUXTRANS[m][mergenum]=TRANSPR[m][mergenum]+TRANSPR[m][mergenum+1];
       for(n=mergenum+1;n<=proposalhiddenstate;n++) MAUXTRANS[m][n]=TRANSPR[m][n+1];}
       
      for(n=1;n<mergenum;n++) MAUXTRANS[mergenum][n]=(PROP[mergenum]*TRANSPR[mergenum][n]+PROP[mergenum+1]*TRANSPR[mergenum+1][n])/(PROP[mergenum]+PROP[mergenum+1]);
      for(n=mergenum+1;n<=proposalhiddenstate;n++) MAUXTRANS[mergenum][n]=(PROP[mergenum]*TRANSPR[mergenum][n+1]+PROP[mergenum+1]*TRANSPR[mergenum+1][n+1])/(PROP[mergenum]+PROP[mergenum+1]);
      sumpr=0.0;
      for(n=1;n<mergenum;n++)  sumpr+=MAUXTRANS[mergenum][n];
      for(n=mergenum+1;n<=proposalhiddenstate;n++) sumpr+=MAUXTRANS[mergenum][n];
      MAUXTRANS[mergenum][mergenum]=1-sumpr;
      
      for(m=mergenum+1;m<=currenthiddenstate;m++)
      {for(n=1;n<mergenum;n++) MAUXTRANS[m][n]=TRANSPR[m+1][n];
       MAUXTRANS[m][mergenum]=TRANSPR[m+1][mergenum]+TRANSPR[m+1][mergenum+1];
       for(n=mergenum+1;n<=proposalhiddenstate;n++) MAUXTRANS[m][n]=TRANSPR[m+1][n+1];}
 
 free_vector(PROP,1,MAXHIDDENSTATE);

 }
